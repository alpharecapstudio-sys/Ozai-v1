import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AlertCircle, CheckCircle2, ShieldCheck } from 'lucide-react';
import { HeaderBar } from './components/HeaderBar';
import { WizardStepper } from './components/WizardStepper';
import {
  WizardStep1Video,
  WizardStep2Voice,
  WizardStep3PreviewCustomize,
  WizardStep4Export,
  WizardStep5Processing,
  WizardStep6Result,
} from './components/StepPanels';
import { CreditModal } from './components/CreditModal';
import { DeployGuideModal } from './components/DeployGuideModal';
import {
  calculateCreditCost,
  computeUploadChunkPlan,
  DEFAULT_AUTO_BLUR_CONFIG,
  DEFAULT_CAPTION_DECORATION,
  DEFAULT_EDGE_VOICE_ID,
  DEFAULT_TTS_ENGINE,
  parseJsonResponseSafe,
  sanitizeAutoBlurRegions,
  splitLongCaptionsToMaxTwoLines,
  splitScriptIntoTimedCaptions,
  truncateThumbnailTitle,
  validateUploadFileSize,
} from './utils/studioLogic';
import { renderViralThumbnailBlob } from './utils/thumbnailCanvas';
import { suggestDefaultAspectRatio } from './utils/thumbnailLogic';
import { DEFAULT_AUTO_SILENCE_CUT_CONFIG } from './utils/audioSync';
import type {
  AutoBlurConfig,
  AutoBlurRegion,
  AutoSilenceCutConfig,
  CaptionAnimationStyle,
  CaptionDecorationConfig,
  CaptionSegment,
  EdgeVoiceId,
  ExportResolution,
  MusicMood,
  MyanmarVoiceId,
  OverlayPosition,
  PipelineProgress,
  RecapQualityValidation,
  RecapSceneMapping,
  SceneAnalysisProvider,
  SceneSummary,
  SilenceCutPlan,
  StudioTool,
  SyncSummary,
  ThumbnailAnalysis,
  ThumbnailAspectRatio,
  TranscriptSegment,
  TtsEngineId,
  VideoTimelineSegment,
  VoiceGender,
  VoiceSpeed,
  WizardStep,
} from './types/studio';

const INITIAL_CAPTIONS: CaptionSegment[] = [
  {
    id: 'cap_1',
    start: 0.2,
    end: 3.8,
    text: 'မိုးရွာနေတဲ့ညမှာ စုံထောက်ကြီး တစ်ယောက်တည်း စောင့်နေတယ်',
    emoji: '🌧️',
  },
  {
    id: 'cap_2',
    start: 4.0,
    end: 7.8,
    text: 'ဒါပေမဲ့ သူ့နောက်ကွယ်က လျှို့ဝှက်ချက်က အရမ်းကြောက်စရာကောင်းတယ်',
    emoji: '😱',
  },
  {
    id: 'cap_3',
    start: 8.0,
    end: 11.8,
    text: 'နောက်ဆုံး ဘယ်သူတရားခံလဲ ဆိုတာ ကြည့်လိုက်ကြရအောင်',
    emoji: '🔥',
  },
];

const INITIAL_SCRIPT_MY =
  'ဟေ့ကောင်တွေ ဒီညကတော့ တကယ်မလွယ်ဘူးနော်။ မိုးရွာနေတဲ့ တံတားပေါ်မှာ စုံထောက်ကြီးက သဲလွန်စတစ်ခုကို စောင့်နေတာ။ ဒါပေမဲ့ တကယ်တမ်း ထင်မှတ်မထားတဲ့ အလှည့်အပြောင်းကြီးက အခုမှ စမှာ!';

export default function App() {
  const sessionId = useMemo(() => crypto.randomUUID(), []);

  // Wizard Navigation State (One step at a time)
  const [currentStep, setCurrentStep] = useState<WizardStep>(1);
  const [maxReachedStep, setMaxReachedStep] = useState<WizardStep>(1);

  const [activeTool, setActiveTool] = useState<StudioTool>('recap');
  const [credits, setCredits] = useState<number>(30);
  const [isCreditModalOpen, setIsCreditModalOpen] = useState(false);
  const [isDeployModalOpen, setIsDeployModalOpen] = useState(false);

  // Step 1: Ephemeral Video Source State
  const [linkInput, setLinkInput] = useState('');
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoTitle, setVideoTitle] = useState<string>('');
  const [durationSeconds, setDurationSeconds] = useState<number>(12);
  const [videoDimensions, setVideoDimensions] = useState<{ width: number; height: number }>({
    width: 1280,
    height: 720,
  });
  const [sourceLoading, setSourceLoading] = useState<boolean>(false);
  const [uploadPercent, setUploadPercent] = useState<number | null>(null);

  // Step 2: AI Voice Engine (Edge Burmese Neural Default / Gemini TTS), Voice, Speed & Crossfade Audio
  const [ttsEngine, setTtsEngine] = useState<TtsEngineId>(DEFAULT_TTS_ENGINE);
  const [edgeVoiceId, setEdgeVoiceId] = useState<EdgeVoiceId>(DEFAULT_EDGE_VOICE_ID);
  const [voiceGender, setVoiceGender] = useState<VoiceGender | null>('female');
  const [voiceStyle, setVoiceStyle] = useState<MyanmarVoiceId>('street_bro');
  const [voiceSpeed, setVoiceSpeed] = useState<VoiceSpeed>(1.0);
  const [musicMood, setMusicMood] = useState<MusicMood>('thriller');
  const [sfxEnabled, setSfxEnabled] = useState<boolean>(true);
  const [voicePreviewUrl, setVoicePreviewUrl] = useState<string | null>(null);
  const [voicePreviewLoading, setVoicePreviewLoading] = useState<boolean>(false);
  const [geminiConfigured, setGeminiConfigured] = useState<boolean>(true);
  const [ttsGenerating, setTtsGenerating] = useState<boolean>(false);

  // Step 3: Captions, Logo & Live Drag Positions
  const [transcriptSegments, setTranscriptSegments] = useState<TranscriptSegment[]>([]);
  const [timelineSegments, setTimelineSegments] = useState<VideoTimelineSegment[]>([]);
  const [scriptMy, setScriptMy] = useState<string>(INITIAL_SCRIPT_MY);
  const [ttsAudioUrl, setTtsAudioUrl] = useState<string | null>(null);
  const [syncSummary, setSyncSummary] = useState<SyncSummary | null>(null);
  const [captions, setCaptions] = useState<CaptionSegment[]>(INITIAL_CAPTIONS);
  const hasUserEditedScriptRef = useRef<boolean>(false);
  const [captionsEnabled, setCaptionsEnabled] = useState<boolean>(true);
  const [captionStyle, setCaptionStyle] = useState<CaptionAnimationStyle>('pop');
  const [captionDecoration, setCaptionDecoration] = useState<CaptionDecorationConfig>(
    DEFAULT_CAPTION_DECORATION
  );
  const [subPos, setSubPos] = useState<OverlayPosition>({ x: 50, y: 80 });
  const [logoPos, setLogoPos] = useState<OverlayPosition>({ x: 86, y: 12 });
  const [logoEnabled, setLogoEnabled] = useState<boolean>(true);
  const [logoScale, setLogoScale] = useState<number>(14);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreviewUrl, setLogoPreviewUrl] = useState<string | null>(null);
  const [autoBlurConfig, setAutoBlurConfig] = useState<AutoBlurConfig>(DEFAULT_AUTO_BLUR_CONFIG);
  const [autoBlurRegions, setAutoBlurRegions] = useState<AutoBlurRegion[]>([]);
  const autoBlurRequestSeqRef = useRef<number>(0);
  const [silenceCutPlan, setSilenceCutPlan] = useState<SilenceCutPlan | null>(null);
  const [silenceDetectLoading, setSilenceDetectLoading] = useState<boolean>(false);
  const [silenceHasAudio, setSilenceHasAudio] = useState<boolean>(true);
  const silenceDetectSeqRef = useRef<number>(0);
  const [scenes, setScenes] = useState<SceneSummary[]>([]);
  const [storyAnalysisMy, setStoryAnalysisMy] = useState<string>('');
  const [step3Loading, setStep3Loading] = useState<boolean>(false);
  const [step3StatusMy, setStep3StatusMy] = useState<string>('');
  const [step3Error, setStep3Error] = useState<string | null>(null);
  const [sceneProvider, setSceneProvider] = useState<SceneAnalysisProvider | null>(null);
  const [sceneFallbackUsed, setSceneFallbackUsed] = useState<boolean>(false);
  const [recapSceneMappings, setRecapSceneMappings] = useState<RecapSceneMapping[]>([]);
  const [recapQualityValidation, setRecapQualityValidation] = useState<RecapQualityValidation | null>(null);
  const sceneAnalyzedVideoKeyRef = useRef<string>('');
  const sceneAnalysisSeqRef = useRef<number>(0);

  // Step 4: Export Quality, Platform Aspect Ratio & Content-Driven Thumbnail
  const [thumbnailTitle, setThumbnailTitle] = useState<string>('ဗီဒီယိုအနှစ်ချုပ်');
  const [thumbnailAspectRatio, setThumbnailAspectRatio] = useState<ThumbnailAspectRatio>('16:9');
  const [thumbnailAnalysis, setThumbnailAnalysis] = useState<ThumbnailAnalysis | null>(null);
  const [thumbnailAnalyzing, setThumbnailAnalyzing] = useState<boolean>(false);
  const [thumbnailUpdating, setThumbnailUpdating] = useState<boolean>(false);
  const [resolution, setResolution] = useState<ExportResolution>('1080p');
  const thumbnailBlobRef = useRef<Blob | null>(null);
  const hasCustomThumbTitleRef = useRef<boolean>(false);
  const analyzedVideoKeyRef = useRef<string>('');

  // Step 5 & 6: Processing, Final Output & Telegram
  const [progress, setProgress] = useState<PipelineProgress | null>(null);
  const [processingError, setProcessingError] = useState<string | null>(null);
  const [finalVideoUrl, setFinalVideoUrl] = useState<string | null>(null);
  const [finalThumbnailUrl, setFinalThumbnailUrl] = useState<string | null>(null);
  const [telegramChatId, setTelegramChatId] = useState<string>('');
  const [telegramSending, setTelegramSending] = useState<boolean>(false);
  const [banner, setBanner] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  const creditCost = calculateCreditCost(activeTool, resolution === '4k', durationSeconds);

  // Check server TTS/AI capabilities once on mount
  useEffect(() => {
    let cancelled = false;
    fetch('/api/health')
      .then((res) => (res.ok ? parseJsonResponseSafe(res) : null))
      .then((data) => {
        if (!cancelled && data && typeof data.geminiConfigured === 'boolean') {
          setGeminiConfigured(data.geminiConfigured);
        }
      })
      .catch(() => {
        // Ignore transient health check failures
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Auto-clean server ephemeral session files when user closes page/tab
  useEffect(() => {
    const cleanup = () => {
      if (navigator.sendBeacon) {
        navigator.sendBeacon(`/api/session/cleanup?sessionId=${encodeURIComponent(sessionId)}`);
      }
    };
    window.addEventListener('pagehide', cleanup);
    window.addEventListener('beforeunload', cleanup);
    return () => {
      window.removeEventListener('pagehide', cleanup);
      window.removeEventListener('beforeunload', cleanup);
      cleanup();
    };
  }, [sessionId]);

  const showError = (text: string) => setBanner({ type: 'error', text });
  const showSuccess = (text: string) => setBanner({ type: 'success', text });

  const goToStep = (step: WizardStep) => {
    setBanner(null);
    setCurrentStep(step);
    setMaxReachedStep((prev) => (step > prev ? step : prev));
  };

  const resetVideoDerivedState = () => {
    setFinalVideoUrl(null);
    setFinalThumbnailUrl(null);
    setTtsAudioUrl(null);
    setSyncSummary(null);
    setTranscriptSegments([]);
    setTimelineSegments([]);
    setThumbnailAnalysis(null);
    setAutoBlurRegions([]);
    setSilenceCutPlan(null);
    setSilenceHasAudio(true);
    setScenes([]);
    setStoryAnalysisMy('');
    setStep3Loading(false);
    setStep3StatusMy('');
    setStep3Error(null);
    setSceneProvider(null);
    setSceneFallbackUsed(false);
    setRecapSceneMappings([]);
    setRecapQualityValidation(null);
    sceneAnalyzedVideoKeyRef.current = '';
    analyzedVideoKeyRef.current = '';
    hasCustomThumbTitleRef.current = false;
    hasUserEditedScriptRef.current = false;
    setProcessingError(null);
  };

  const detectSilencesForSession = async (
    cfg: AutoSilenceCutConfig = DEFAULT_AUTO_SILENCE_CUT_CONFIG
  ) => {
    const seq = ++silenceDetectSeqRef.current;
    setSilenceDetectLoading(true);
    try {
      const res = await fetch('/api/detect-silences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          noiseThresholdDb: cfg.noiseThresholdDb,
          minSilenceDuration: cfg.minSilenceDuration,
          paddingSeconds: cfg.paddingSeconds,
        }),
      });
      const payload = await parseJsonResponseSafe(res);
      if (silenceDetectSeqRef.current !== seq) return;
      if (res.ok) {
        setSilenceHasAudio(payload?.hasAudio !== false);
        setSilenceCutPlan((payload?.plan as SilenceCutPlan | undefined) || null);
      }
    } catch {
      // Leave plan untouched on transient network failure
    } finally {
      if (silenceDetectSeqRef.current === seq) {
        setSilenceDetectLoading(false);
      }
    }
  };

  const detectAutoBlurInBackground = async (requestSeq: number) => {
    try {
      const res = await fetch('/api/detect-auto-blur', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId }),
      });
      if (!res.ok) return;
      const payload = await parseJsonResponseSafe(res);
      if (autoBlurRequestSeqRef.current !== requestSeq) return;
      setAutoBlurRegions(sanitizeAutoBlurRegions(payload?.regions as AutoBlurRegion[] | undefined));
    } catch {
      // Silent background detection failure leaves video cleanly unblurred
    }
  };

  const applyVideoSourceMeta = (data: {
    videoUrl: string;
    title: string;
    durationSeconds?: number;
    width?: number;
    height?: number;
  }) => {
    setVideoUrl(data.videoUrl);
    setVideoTitle(data.title);
    setDurationSeconds(data.durationSeconds || 12);
    if (data.width && data.height) {
      setVideoDimensions({ width: data.width, height: data.height });
      setThumbnailAspectRatio(suggestDefaultAspectRatio(data.width, data.height));
    } else {
      setVideoDimensions({ width: 1280, height: 720 });
    }
    resetVideoDerivedState();
    const seq = ++autoBlurRequestSeqRef.current;
    void detectAutoBlurInBackground(seq);
    void detectSilencesForSession(DEFAULT_AUTO_SILENCE_CUT_CONFIG);
  };

  const handleLoadSample = async () => {
    setBanner(null);
    setSourceLoading(true);
    try {
      const res = await fetch('/api/load-sample', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId }),
      });
      const data = await parseJsonResponseSafe(res);
      if (!res.ok) {
        showError(String(data.errorMy || 'နမူနာဗီဒီယို ဖွင့်၍မရပါ'));
        return;
      }
      applyVideoSourceMeta(data as { videoUrl: string; title: string; durationSeconds?: number; width?: number; height?: number });
      showSuccess('နမူနာရုပ်ရှင်ကို ထည့်သွင်းပြီးပါပြီ — “ရှေ့ဆက်မည်” ကို နှိပ်ပါ');
    } catch {
      showError('Server နှင့် ချိတ်ဆက်ရာတွင် အမှားဖြစ်ပွားပါသည်');
    } finally {
      setSourceLoading(false);
    }
  };

  const handleSubmitLink = async () => {
    setBanner(null);
    setSourceLoading(true);
    try {
      const res = await fetch('/api/resolve-link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: linkInput, sessionId }),
      });
      const data = await parseJsonResponseSafe(res);
      if (!res.ok) {
        showError(String(data.errorMy || 'ဗီဒီယိုလင့်ခ် စစ်ဆေးရာတွင် အမှားဖြစ်ပွားပါသည်'));
        return;
      }
      applyVideoSourceMeta(data as { videoUrl: string; title: string; durationSeconds?: number; width?: number; height?: number });
      showSuccess(`${String(data.platform || 'Video')} ဗီဒီယိုကို အောင်မြင်စွာ ထည့်သွင်းပြီးပါပြီ`);
    } catch {
      showError('လင့်ခ်မှ ဗီဒီယိုရယူရာတွင် အမှားဖြစ်ပွားပါသည်');
    } finally {
      setSourceLoading(false);
    }
  };

  const handleUploadMp4 = async (file: File) => {
    setBanner(null);
    const sizeCheck = validateUploadFileSize(file.size);
    if (!sizeCheck.valid) {
      showError(sizeCheck.errorMy || 'ဗီဒီယိုဖိုင် အရွယ်အစား မမှန်ကန်ပါ');
      return;
    }

    setSourceLoading(true);
    setUploadPercent(0);
    try {
      const plan = computeUploadChunkPlan(file.size);
      let data: Record<string, unknown> = {};

      if (!plan.useChunked) {
        const form = new FormData();
        form.append('sessionId', sessionId);
        form.append('video', file);
        const res = await fetch('/api/upload-video', {
          method: 'POST',
          headers: { 'x-session-id': sessionId },
          body: form,
        });
        data = await parseJsonResponseSafe(res);
        if (!res.ok) {
          showError(String(data.errorMy || 'MP4 ဖိုင်တင်သွင်းရာတွင် အမှားဖြစ်ပွားပါသည်'));
          return;
        }
        setUploadPercent(100);
      } else {
        const uploadId = crypto.randomUUID().replace(/[^a-zA-Z0-9]/g, '').slice(0, 16);
        for (let idx = 0; idx < plan.totalChunks; idx++) {
          const start = idx * plan.chunkSizeBytes;
          const end = Math.min(file.size, start + plan.chunkSizeBytes);
          const slice = file.slice(start, end);

          let chunkOk = false;
          let lastChunkErr = 'MP4 ဖိုင်အပိုင်း တင်သွင်းရာတွင် အမှားဖြစ်ပွားပါသည်';

          for (let attempt = 0; attempt < 3; attempt++) {
            try {
              const chunkForm = new FormData();
              chunkForm.append('sessionId', sessionId);
              chunkForm.append('uploadId', uploadId);
              chunkForm.append('chunkIndex', String(idx));
              chunkForm.append('totalChunks', String(plan.totalChunks));
              chunkForm.append('chunk', slice, `${file.name}.part${idx}`);

              const cRes = await fetch('/api/upload-video/chunk', {
                method: 'POST',
                headers: { 'x-session-id': sessionId },
                body: chunkForm,
              });
              const cData = await parseJsonResponseSafe(cRes);
              if (cRes.ok) {
                chunkOk = true;
                break;
              }
              lastChunkErr = String(cData.errorMy || lastChunkErr);
              if (cRes.status >= 400 && cRes.status < 500) break;
            } catch {
              // Retry transient network reset/disconnect
            }
            await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
          }

          if (!chunkOk) {
            showError(lastChunkErr);
            return;
          }
          setUploadPercent(Math.min(95, Math.round(((idx + 1) / plan.totalChunks) * 95)));
        }

        const completeRes = await fetch('/api/upload-video/complete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-session-id': sessionId },
          body: JSON.stringify({
            sessionId,
            uploadId,
            totalChunks: plan.totalChunks,
            filename: file.name,
          }),
        });
        data = await parseJsonResponseSafe(completeRes);
        if (!completeRes.ok) {
          showError(String(data.errorMy || 'MP4 ဖိုင်ပေါင်းစည်းရာတွင် အမှားဖြစ်ပွားပါသည်'));
          return;
        }
        setUploadPercent(100);
      }

      applyVideoSourceMeta({
        videoUrl: String(data.videoUrl || ''),
        durationSeconds: Number(data.durationSeconds || 0),
        width: Number(data.width || 1280),
        height: Number(data.height || 720),
        title: String(data.title || file.name),
      });
      showSuccess('MP4 ဗီဒီယိုဖိုင်ကို စစ်ဆေးထည့်သွင်းပြီးပါပြီ');
    } catch {
      showError('MP4 ဖိုင်တင်သွင်းရာတွင် ကွန်ရက်ချိတ်ဆက်မှု အမှားဖြစ်ပွားပါသည် — ထပ်မံကြိုးစားပါ');
    } finally {
      setSourceLoading(false);
      setUploadPercent(null);
    }
  };

  const analyzeVideoContentThumbnail = async (
    ratioOverride?: ThumbnailAspectRatio,
    contextOverride?: { transcript?: string; scriptMy?: string; silent?: boolean }
  ): Promise<ThumbnailAnalysis | null> => {
    if (!videoUrl) return null;
    const ratio = ratioOverride ?? thumbnailAspectRatio;
    setThumbnailAnalyzing(true);
    try {
      const res = await fetch('/api/analyze-thumbnail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          aspectRatio: ratio,
          transcript:
            contextOverride?.transcript ??
            transcriptSegments.map((s) => s.text).join(' '),
          scriptMy: contextOverride?.scriptMy ?? scriptMy,
          videoTitle,
        }),
      });
      const data = await parseJsonResponseSafe(res);
      if (!res.ok) {
        if (!contextOverride?.silent) {
          showError(String(data.errorMy || 'ဗီဒီယိုဖရိန်များ စစ်ဆေးရာတွင် အမှားဖြစ်ပွားပါသည်'));
        }
        return null;
      }
      const analysis = data as unknown as ThumbnailAnalysis;
      analyzedVideoKeyRef.current = `${sessionId}:${videoUrl}`;
      setThumbnailAnalysis(analysis);
      if (!hasCustomThumbTitleRef.current && analysis.headlineMy) {
        setThumbnailTitle(truncateThumbnailTitle(analysis.headlineMy));
      }
      if (!contextOverride?.silent) {
        showSuccess(`ဗီဒီယိုမှ ${analysis.subjectLabelMy} ကို တွေ့ရှိပြီး Thumbnail ပြင်ဆင်ပြီးပါပြီ`);
      }
      return analysis;
    } catch {
      if (!contextOverride?.silent) {
        showError('ဗီဒီယို Thumbnail စစ်ဆေးရာတွင် ချိတ်ဆက်မှု အမှားဖြစ်ပွားပါသည်');
      }
      return null;
    } finally {
      setThumbnailAnalyzing(false);
    }
  };

  const analyzeVideoScenes = async (options?: { forceRestart?: boolean }) => {
    if (!videoUrl) return;
    const seq = ++sceneAnalysisSeqRef.current;
    setStep3Loading(true);
    setStep3Error(null);
    setSceneProvider('gemini');
    setStep3StatusMy('Gemini API အသုံးပြုနေသည်');

    try {
      const res = await fetch('/api/analyze-scenes?stream=1', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/x-ndjson',
        },
        body: JSON.stringify({
          sessionId,
          videoTitle,
          forceRestart: options?.forceRestart === true,
          transcript: transcriptSegments.map((s) => s.text).join(' ').trim(),
          segments: transcriptSegments,
        }),
      });

      if (!res.ok && !res.body) {
        const errData = await parseJsonResponseSafe(res);
        throw new Error(String(errData.errorMy || 'Scene စစ်ဆေးရာတွင် အမှားဖြစ်ပွားပါသည်'));
      }

      const contentType = String(res.headers.get('content-type') || '').toLowerCase();
      let finalPayload: Record<string, unknown> | null = null;

      if (contentType.includes('application/x-ndjson') && res.body) {
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        const processLine = (line: string) => {
          const trimmed = line.trim();
          if (!trimmed || sceneAnalysisSeqRef.current !== seq) return;
          if (trimmed.startsWith('<')) {
            throw new Error('ဆာဗာ လုပ်ဆောင်ချိန် ကြာမြင့်သွားပါသည် သို့မဟုတ် ယာယီပြတ်တောက်နေပါသည် — ထပ်မံကြိုးစားပါ');
          }
          let evt: Record<string, unknown>;
          try {
            evt = JSON.parse(trimmed) as Record<string, unknown>;
          } catch {
            throw new Error('Scene စစ်ဆေးမှု တုံ့ပြန်ချက် မမှန်ကန်ပါ — ထပ်မံကြိုးစားပါ');
          }
          const evtType = String(evt.type || '');

          if (evt.activeProvider === 'gemini' || evt.activeProvider === 'groq') {
            setSceneProvider(evt.activeProvider);
          }
          if (typeof evt.fallbackUsed === 'boolean') {
            setSceneFallbackUsed(evt.fallbackUsed);
          }
          if (typeof evt.statusMy === 'string' && evt.statusMy) {
            setStep3StatusMy(evt.statusMy);
          }
          if (Array.isArray(evt.scenes) && evt.scenes.length > 0) {
            setScenes(evt.scenes as SceneSummary[]);
          }

          if (evtType === 'error') {
            throw new Error(String(evt.errorMy || 'Scene စစ်ဆေးရာတွင် အမှားဖြစ်ပွားပါသည်'));
          }
          if (evtType === 'complete') {
            finalPayload = evt;
          }
        };

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() ?? '';
          for (const line of lines) {
            processLine(line);
          }
        }
        if (buffer.trim()) {
          processLine(buffer);
        }
      } else {
        const json = await parseJsonResponseSafe(res);
        if (!res.ok) {
          if (Array.isArray(json.scenes) && json.scenes.length > 0) {
            setScenes(json.scenes as SceneSummary[]);
          }
          throw new Error(String(json.errorMy || 'Scene စစ်ဆေးရာတွင် အမှားဖြစ်ပွားပါသည်'));
        }
        finalPayload = json;
      }

      if (sceneAnalysisSeqRef.current !== seq || !finalPayload) return;

      const resolvedScenes = Array.isArray(finalPayload.scenes)
        ? (finalPayload.scenes as SceneSummary[])
        : scenes;
      const resolvedStory = String(finalPayload.storyAnalysisMy || '').trim();
      const resolvedProvider: SceneAnalysisProvider =
        finalPayload.activeProvider === 'groq' ? 'groq' : 'gemini';

      setScenes(resolvedScenes);
      setStoryAnalysisMy(resolvedStory);
      setSceneProvider(resolvedProvider);
      setSceneFallbackUsed(Boolean(finalPayload.fallbackUsed));
      setStep3StatusMy(
        String(
          finalPayload.providerStatusMy ||
            (resolvedProvider === 'groq'
              ? 'Groq AI ဖြင့် ဇာတ်လမ်းစစ်ဆေးပြီးစီးပါပြီ'
              : 'Gemini API ဖြင့် ဇာတ်လမ်းစစ်ဆေးပြီးစီးပါပြီ')
        )
      );
      sceneAnalyzedVideoKeyRef.current = `${sessionId}:${videoUrl}`;

      const returnedSegs = Array.isArray(finalPayload.segments)
        ? (finalPayload.segments as TranscriptSegment[])
        : transcriptSegments;
      if (returnedSegs.length > 0 && transcriptSegments.length === 0) {
        setTranscriptSegments(returnedSegs);
      }

      // Generate cohesive Natural-Dialogue Recap script preview right in Step 3 if user hasn't manually edited it yet
      if (activeTool === 'recap' && !hasUserEditedScriptRef.current && resolvedScenes.length > 0) {
        try {
          const transcriptForScript =
            String(finalPayload.transcript || '').trim() ||
            returnedSegs.map((s) => s.text).join(' ').trim();
          const sRes = await fetch('/api/generate-script', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              sessionId,
              transcript: transcriptForScript,
              segments: returnedSegs,
              scenes: resolvedScenes,
              storyAnalysisMy: resolvedStory,
              videoTitle,
              tool: 'recap',
              voiceStyle,
              voiceSpeed,
              durationSeconds,
              videoWidth: videoDimensions.width,
              videoHeight: videoDimensions.height,
            }),
          });
          if (sRes.ok && sceneAnalysisSeqRef.current === seq) {
            const sData = await parseJsonResponseSafe(sRes);
            if (Array.isArray(sData.sceneMappings)) {
              setRecapSceneMappings(sData.sceneMappings as RecapSceneMapping[]);
            }
            if (sData.qualityValidation) {
              setRecapQualityValidation(sData.qualityValidation as RecapQualityValidation);
            }
            if (typeof sData.scriptMy === 'string' && sData.scriptMy.trim() && !hasUserEditedScriptRef.current) {
              setScriptMy(sData.scriptMy);
              if (Array.isArray(sData.captions) && sData.captions.length > 0) {
                setCaptions(
                  splitLongCaptionsToMaxTwoLines(sData.captions as CaptionSegment[], {
                    videoWidth: videoDimensions.width,
                    videoHeight: videoDimensions.height,
                    fontSizeScale: captionDecoration.fontSizeScale,
                  })
                );
              }
            }
          }
        } catch {
          // Keep existing script untouched if optional Step 3 script preview fails
        }
      }
    } catch (err) {
      if (sceneAnalysisSeqRef.current !== seq) return;
      const msg = err instanceof Error ? err.message : 'ဗီဒီယို Scene စစ်ဆေးရာတွင် အမှားဖြစ်ပွားပါသည်';
      setStep3Error(msg);
    } finally {
      if (sceneAnalysisSeqRef.current === seq) {
        setStep3Loading(false);
      }
    }
  };

  // Auto-analyze video scenes for Movie Recap on Step 3 entry
  useEffect(() => {
    const key = videoUrl ? `${sessionId}:${videoUrl}` : '';
    if (
      currentStep === 3 &&
      activeTool === 'recap' &&
      videoUrl &&
      !step3Loading &&
      sceneAnalyzedVideoKeyRef.current !== key
    ) {
      void analyzeVideoScenes();
    }
  }, [currentStep, activeTool, videoUrl, sessionId]);

  // Auto-analyze video frames cleanly when user lands on Step 4 without prior analysis
  useEffect(() => {
    if (currentStep === 4 && videoUrl && !thumbnailAnalysis && !thumbnailAnalyzing) {
      void analyzeVideoContentThumbnail(thumbnailAspectRatio, { silent: true });
    }
  }, [currentStep, videoUrl]);

  const handleUploadLogo = (file: File) => {
    setLogoFile(file);
    setLogoEnabled(true);
    setLogoPreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return URL.createObjectURL(file);
    });
    showSuccess('ကိုယ်ပိုင် Logo ပုံကို ထည့်သွင်းပြီးပါပြီ — ဗီဒီယိုပေါ်တွင် ဆွဲရွှေ့နိုင်ပါသည်');
  };

  const handleUpdateCaption = (id: string, field: 'text' | 'emoji', value: string) => {
    if (field === 'text') {
      hasUserEditedScriptRef.current = true;
      setTtsAudioUrl(null);
    }
    setCaptions((prev) => {
      const next = prev.map((c) => (c.id === id ? { ...c, [field]: value } : c));
      if (field === 'text') {
        setScriptMy(next.map((c) => c.text.replace(/\n+/g, ' ').trim()).filter(Boolean).join(' '));
      }
      return next;
    });
  };

  const handleNormalizeLongCaptions = () => {
    setCaptions((prev) =>
      splitLongCaptionsToMaxTwoLines(prev, {
        videoWidth: videoDimensions.width,
        videoHeight: videoDimensions.height,
        fontSizeScale: captionDecoration.fontSizeScale,
      })
    );
  };

  const handlePreviewVoice = async () => {
    if (ttsEngine === 'gemini-tts' && !voiceGender) {
      showError('နမူနာအသံ နားဆင်ရန် Male Voice သို့မဟုတ် Female Voice ကို ဦးစွာ ရွေးချယ်ပါ');
      return;
    }
    setBanner(null);
    setVoicePreviewLoading(true);
    try {
      const res = await fetch('/api/preview-voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ttsEngine,
          voiceId: ttsEngine === 'edge-tts' ? edgeVoiceId : undefined,
          voiceStyle,
          voiceGender: ttsEngine === 'edge-tts' ? (edgeVoiceId === 'my-MM-ThihaNeural' ? 'male' : 'female') : voiceGender,
          speed: voiceSpeed,
        }),
      });
      const data = await parseJsonResponseSafe(res);
      if (!res.ok) {
        showError(String(data.errorMy || 'AI အသံနမူနာ ထုတ်လုပ်ရာတွင် အမှားဖြစ်ပွားပါသည်'));
        return;
      }
      if (data.audioUrl) {
        setVoicePreviewUrl(`${String(data.audioUrl)}?t=${Date.now()}`);
      }
    } catch {
      showError('AI အသံနမူနာ ဆာဗာနှင့် ချိတ်ဆက်ရာတွင် အမှားဖြစ်ပွားပါသည်');
    } finally {
      setVoicePreviewLoading(false);
    }
  };

  const handleGenerateStep3AudioPreview = async () => {
    if (activeTool === 'captions') return;
    if (ttsEngine === 'gemini-tts' && !voiceGender) {
      showError('Gemini TTS အသံမထုတ်လုပ်မီ Male Voice သို့မဟုတ် Female Voice ကို အဆင့် (၂) တွင် ရွေးချယ်ပါ');
      return;
    }
    setBanner(null);
    setTtsGenerating(true);
    try {
      const effectiveVoiceGender: VoiceGender =
        ttsEngine === 'edge-tts'
          ? edgeVoiceId === 'my-MM-ThihaNeural'
            ? 'male'
            : 'female'
          : voiceGender || 'female';

      const targetCaptions =
        activeTool === 'recap' && (captions.length === 0 || hasUserEditedScriptRef.current)
          ? splitScriptIntoTimedCaptions(scriptMy, Math.max(4, durationSeconds))
          : captions;

      const res = await fetch('/api/generate-tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          tool: activeTool,
          ttsEngine,
          voiceId: ttsEngine === 'edge-tts' ? edgeVoiceId : undefined,
          scriptMy,
          speed: voiceSpeed,
          voiceStyle,
          voiceGender: effectiveVoiceGender,
          captions: targetCaptions,
          timelineSegments: activeTool === 'dubbing' ? timelineSegments : [],
          scenes: activeTool === 'recap' ? scenes : undefined,
          storyAnalysisMy: activeTool === 'recap' ? storyAnalysisMy : undefined,
          durationSeconds,
        }),
      });
      const data = await parseJsonResponseSafe(res);
      if (!res.ok) {
        showError(String(data.errorMy || 'AI TTS အသံထုတ်လုပ်ရာတွင် အမှားဖြစ်ပွားပါသည်'));
        return;
      }
      setTtsAudioUrl(data.audioUrl ? `${String(data.audioUrl)}?t=${Date.now()}` : null);
      if (data.syncSummary) setSyncSummary(data.syncSummary as SyncSummary);
      if (activeTool === 'recap') {
        if (typeof data.scriptMy === 'string' && data.scriptMy.trim() && !hasUserEditedScriptRef.current) {
          setScriptMy(data.scriptMy);
        }
        if (Array.isArray(data.sceneMappings)) {
          setRecapSceneMappings(data.sceneMappings as RecapSceneMapping[]);
        }
        if (data.qualityValidation) {
          setRecapQualityValidation(data.qualityValidation as RecapQualityValidation);
        }
      }
      if (activeTool === 'dubbing' && Array.isArray(data.timelineSegments) && data.timelineSegments.length > 0) {
        setTimelineSegments(data.timelineSegments as VideoTimelineSegment[]);
      }
      if (Array.isArray(data.syncedCaptions)) {
        setCaptions(
          splitLongCaptionsToMaxTwoLines(data.syncedCaptions as CaptionSegment[], {
            videoWidth: videoDimensions.width,
            videoHeight: videoDimensions.height,
            fontSizeScale: captionDecoration.fontSizeScale,
          })
        );
      }
      showSuccess('မြန်မာ AI အသံကို ထုတ်လုပ်ပြီးပါပြီ — Preview Player ဖြင့် နားဆင်နိုင်ပါသည်');
    } catch {
      showError('AI အသံထုတ်လုပ်ရာတွင် ဆာဗာနှင့် ချိတ်ဆက်မှု အမှားဖြစ်ပွားပါသည်');
    } finally {
      setTtsGenerating(false);
    }
  };

  const runFullGenerationPipeline = async () => {
    if (activeTool !== 'captions' && ttsEngine === 'gemini-tts' && !voiceGender) {
      showError('Gemini TTS အသံမထုတ်လုပ်မီ Male Voice သို့မဟုတ် Female Voice ကို အဆင့် (၂) တွင် ရွေးချယ်ပါ');
      setCurrentStep(2);
      return;
    }
    if (credits < creditCost) {
      showError('ခရက်ဒစ် မလုံလောက်ပါ — ကျေးဇူးပြု၍ ခရက်ဒစ် ထပ်မံဝယ်ယူပါ');
      setIsCreditModalOpen(true);
      return;
    }

    setBanner(null);
    setProcessingError(null);
    setCurrentStep(5);
    setMaxReachedStep((prev) => (prev < 5 ? 5 : prev));

    try {
      const keepManualStep3Edits = hasUserEditedScriptRef.current && transcriptSegments.length > 0;
      let segs = transcriptSegments;
      let groqTimeline = timelineSegments;
      let transcriptText = transcriptSegments.map((s) => s.text).join(' ');

      if (!keepManualStep3Edits) {
        // 1. Groq Audio Analysis / Timestamp Extraction
        setProgress({
          step: 1,
          totalSteps: 4,
          labelMy:
            activeTool === 'dubbing'
              ? 'Groq API ဖြင့် စကားပြောအပိုင်းနှင့် တိတ်ဆိတ်အပိုင်းများကို အချိန်အတိအကျ ခွဲထုတ်နေသည်...'
              : 'Groq API ဖြင့် ဗီဒီယိုအကြောင်းအရာနှင့် စာသားအချိန်မှတ်တမ်း ထုတ်ယူနေသည်...',
          percent: 20,
        });
        const tRes = await fetch('/api/transcribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionId }),
        });
        const tData = await parseJsonResponseSafe(tRes);
        if (!tRes.ok) {
          throw new Error(String(tData.errorMy || 'Groq Transcript ထုတ်ယူရာတွင် အမှားဖြစ်ပွားပါသည်'));
        }
        segs = Array.isArray(tData.segments) ? (tData.segments as TranscriptSegment[]) : [];
        groqTimeline = Array.isArray(tData.timelineSegments)
          ? (tData.timelineSegments as VideoTimelineSegment[])
          : timelineSegments;
        transcriptText = String(tData.transcript || '');
        setTranscriptSegments(segs);
        setTimelineSegments(activeTool === 'dubbing' ? groqTimeline : []);
      }

      let nextScript = scriptMy;
      let scriptedTimeline = activeTool === 'dubbing' ? groqTimeline : [];
      let finalCaptions: CaptionSegment[] = captions;
      let sDataThumbTitle = '';

      if (!keepManualStep3Edits) {
        // 2. Gemini Script Generation (Tool-specific: full Recap vs Speaking-Only Dubbing vs Original-Audio Captions)
        setProgress({
          step: 2,
          totalSteps: 4,
          labelMy:
            activeTool === 'recap'
              ? 'ဗီဒီယိုတစ်ခုလုံးအတွက် မြန်မာ Movie Recap ဇာတ်ညွှန်းအသစ် ရေးသားနေသည်...'
              : activeTool === 'captions'
                ? 'မူရင်းအသံအတွက် Dynamic Myanmar Captions ဘာသာပြန် ရေးသားနေသည်...'
                : 'စကားပြောအပိုင်းများအတွက်သာ မြန်မာ Dubbing ဇာတ်ညွှန်း ရေးသားနေသည်...',
          percent: 45,
        });
        const sRes = await fetch('/api/generate-script', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId,
            transcript: transcriptText,
            segments: segs.length > 0 ? segs : transcriptSegments,
            timelineSegments: activeTool === 'dubbing' ? groqTimeline : undefined,
            scenes: activeTool === 'recap' ? scenes : undefined,
            storyAnalysisMy: activeTool === 'recap' ? storyAnalysisMy : undefined,
            videoTitle: activeTool === 'recap' ? videoTitle : undefined,
            tool: activeTool,
            voiceStyle,
            voiceSpeed,
            durationSeconds,
            videoWidth: videoDimensions.width,
            videoHeight: videoDimensions.height,
          }),
        });
        const sData = await parseJsonResponseSafe(sRes);
        if (!sRes.ok) {
          throw new Error(String(sData.errorMy || 'Gemini ဇာတ်ညွှန်းဖန်တီးရာတွင် အမှားဖြစ်ပွားပါသည်'));
        }

        nextScript = String(sData.scriptMy ?? scriptMy);
        scriptedTimeline =
          activeTool === 'dubbing' && Array.isArray(sData.timelineSegments)
            ? (sData.timelineSegments as VideoTimelineSegment[])
            : [];
        sDataThumbTitle = String(sData.thumbnailTitleMy || '');
        setTimelineSegments(scriptedTimeline);
        if (activeTool === 'recap') {
          if (Array.isArray(sData.sceneMappings)) {
            setRecapSceneMappings(sData.sceneMappings as RecapSceneMapping[]);
          }
          if (sData.qualityValidation) {
            setRecapQualityValidation(sData.qualityValidation as RecapQualityValidation);
          }
        }

        finalCaptions = splitLongCaptionsToMaxTwoLines(
          Array.isArray(sData.captions) ? (sData.captions as CaptionSegment[]) : captions,
          {
            videoWidth: videoDimensions.width,
            videoHeight: videoDimensions.height,
            fontSizeScale: captionDecoration.fontSizeScale,
          }
        );

        setScriptMy(nextScript);
        setCaptions(finalCaptions);
      } else if (activeTool === 'recap' && captions.length === 0) {
        finalCaptions = splitLongCaptionsToMaxTwoLines(
          splitScriptIntoTimedCaptions(nextScript, Math.max(4, durationSeconds)),
          {
            videoWidth: videoDimensions.width,
            videoHeight: videoDimensions.height,
            fontSizeScale: captionDecoration.fontSizeScale,
          }
        );
        setCaptions(finalCaptions);
      }

      // 2b. Video Content-Driven Thumbnail Analysis (reuse Step 4 analysis if already extracted for this video)
      const videoAnalysisKey = videoUrl ? `${sessionId}:${videoUrl}` : '';
      const hasExistingAnalysis =
        Boolean(thumbnailAnalysis) &&
        Boolean(videoAnalysisKey) &&
        analyzedVideoKeyRef.current === videoAnalysisKey;
      const latestThumbAnalysis = hasExistingAnalysis
        ? thumbnailAnalysis
        : (await analyzeVideoContentThumbnail(thumbnailAspectRatio, {
            transcript: transcriptText,
            scriptMy: nextScript,
            silent: true,
          })) || thumbnailAnalysis;

      const resolvedThumbTitle = truncateThumbnailTitle(
        (hasCustomThumbTitleRef.current ? thumbnailTitle.trim() : '') ||
          latestThumbAnalysis?.headlineMy ||
          sDataThumbTitle ||
          thumbnailTitle.trim() ||
          'ဗီဒီယိုအနှစ်ချုပ်'
      );
      setThumbnailTitle(resolvedThumbTitle);

      // 3. Tool-specific TTS Step:
      //    - 'recap': full continuous TTS narration across whole video
      //    - 'dubbing': per-speaking-segment TTS (silence stays 1.0x)
      //    - 'captions': NO AI voice, preserve original video audio
      let plannedTimeline = scriptedTimeline;
      if (activeTool === 'captions') {
        setTtsAudioUrl(null);
        setSyncSummary({
          tool: 'captions',
          segmentCount: finalCaptions.length,
          originalVideoDuration: durationSeconds,
          aiVoiceDuration: 0,
          finalVideoDuration: durationSeconds,
          videoPlaybackRate: 1.0,
          voiceSpeed,
        });
      } else {
        setProgress({
          step: 3,
          totalSteps: 4,
          labelMy:
            activeTool === 'recap'
              ? 'ဗီဒီယိုတစ်ခုလုံးအတွက် မြန်မာ Recap AI အသံ ဖန်တီးနေသည်...'
              : 'စကားပြောအပိုင်းတစ်ခုချင်းစီအတွက် Gemini TTS ထုတ်ပြီး စကားပြောအပိုင်းအမြန်နှုန်းကိုသာ ညှိနေသည်...',
          percent: 70,
        });
        const effectiveVoiceGender: VoiceGender =
          ttsEngine === 'edge-tts'
            ? edgeVoiceId === 'my-MM-ThihaNeural'
              ? 'male'
              : 'female'
            : voiceGender || 'female';

        const ttsRes = await fetch('/api/generate-tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId,
            tool: activeTool,
            ttsEngine,
            voiceId: ttsEngine === 'edge-tts' ? edgeVoiceId : undefined,
            scriptMy: nextScript,
            speed: voiceSpeed,
            voiceStyle,
            voiceGender: effectiveVoiceGender,
            captions: finalCaptions,
            timelineSegments: activeTool === 'dubbing' ? scriptedTimeline : [],
            scenes: activeTool === 'recap' ? scenes : undefined,
            storyAnalysisMy: activeTool === 'recap' ? storyAnalysisMy : undefined,
            durationSeconds,
          }),
        });
        const ttsData = await parseJsonResponseSafe(ttsRes);
        if (!ttsRes.ok) {
          throw new Error(String(ttsData.errorMy || 'AI TTS အသံထုတ်လုပ်ရာတွင် အမှားဖြစ်ပွားပါသည်'));
        }
        setTtsAudioUrl(ttsData.audioUrl ? String(ttsData.audioUrl) : null);
        setSyncSummary((ttsData.syncSummary as SyncSummary | undefined) || null);
        if (activeTool === 'recap') {
          if (typeof ttsData.scriptMy === 'string' && ttsData.scriptMy.trim() && !keepManualStep3Edits) {
            nextScript = ttsData.scriptMy;
            setScriptMy(ttsData.scriptMy);
          }
          if (Array.isArray(ttsData.sceneMappings)) {
            setRecapSceneMappings(ttsData.sceneMappings as RecapSceneMapping[]);
          }
          if (ttsData.qualityValidation) {
            setRecapQualityValidation(ttsData.qualityValidation as RecapQualityValidation);
          }
        }
        if (activeTool === 'dubbing' && Array.isArray(ttsData.timelineSegments) && ttsData.timelineSegments.length > 0) {
          plannedTimeline = ttsData.timelineSegments as VideoTimelineSegment[];
          setTimelineSegments(plannedTimeline);
        }
        if (Array.isArray(ttsData.syncedCaptions)) {
          finalCaptions = splitLongCaptionsToMaxTwoLines(ttsData.syncedCaptions as CaptionSegment[], {
            videoWidth: videoDimensions.width,
            videoHeight: videoDimensions.height,
            fontSizeScale: captionDecoration.fontSizeScale,
          });
          setCaptions(finalCaptions);
        }
      }

      // 4. Final 1080p / 4K Render
      setProgress({
        step: 4,
        totalSteps: 4,
        labelMy:
          activeTool === 'recap'
            ? `AI Recap အသံနှင့် ဗီဒီယိုတစ်ခုလုံး ကိုက်ညီအောင် ${resolution.toUpperCase()} ထုတ်လုပ်နေသည်...`
            : activeTool === 'captions'
              ? `မူရင်းအသံ (1.0x) နှင့် Dynamic Captions များကို ${resolution.toUpperCase()} ထုတ်လုပ်နေသည်...`
              : `ညှိပြီးသား စကားပြောအပိုင်းနှင့် 1.0x တိတ်ဆိတ်အပိုင်းများကို ${resolution.toUpperCase()} အဖြစ် ပေါင်းစည်းနေသည်...`,
        percent: 90,
      });

      const freshThumbBlob =
        (await renderViralThumbnailBlob(
          resolvedThumbTitle,
          videoUrl,
          thumbnailAspectRatio,
          latestThumbAnalysis
        )) || thumbnailBlobRef.current;

      const form = new FormData();
      form.append('sessionId', sessionId);
      form.append('tool', activeTool);
      form.append('resolution', resolution);
      form.append('musicMood', musicMood);
      form.append('crossfadeSeconds', '2.0');
      form.append('sfxEnabled', String(sfxEnabled));
      form.append('captionsEnabled', String(captionsEnabled));
      form.append('logoEnabled', String(logoEnabled));
      form.append('logoScale', String(logoScale));
      form.append('subPos', JSON.stringify(subPos));
      form.append('logoPos', JSON.stringify(logoPos));
      form.append('captions', JSON.stringify(finalCaptions));
      form.append('captionDecoration', JSON.stringify(captionDecoration));
      form.append('autoBlurConfig', JSON.stringify(autoBlurConfig));
      form.append('autoBlurRegions', JSON.stringify(autoBlurRegions));
      form.append('autoSilenceCutConfig', JSON.stringify(DEFAULT_AUTO_SILENCE_CUT_CONFIG));
      if (activeTool === 'dubbing') {
        form.append('timelineSegments', JSON.stringify(plannedTimeline));
      }
      form.append('thumbnailTitle', resolvedThumbTitle);
      form.append('thumbnailAspectRatio', thumbnailAspectRatio);

      if (logoEnabled && logoFile) {
        form.append('logo', logoFile);
      }
      if (freshThumbBlob) {
        form.append('thumbnail', freshThumbBlob, 'thumbnail.jpg');
      }

      const renderRes = await fetch('/api/render-video', {
        method: 'POST',
        headers: { 'x-session-id': sessionId },
        body: form,
      });
      const renderData = await parseJsonResponseSafe(renderRes);
      if (!renderRes.ok) {
        throw new Error(String(renderData.errorMy || 'ဗီဒီယို အပြီးသတ်ထုတ်လုပ်ရာတွင် အမှားဖြစ်ပွားပါသည်'));
      }

      const cutPlan = renderData.silenceCutPlan as SilenceCutPlan | undefined;
      if (cutPlan?.didCut) {
        setSyncSummary((prev) =>
          prev
            ? {
                ...prev,
                silenceCutRemovedSeconds: cutPlan.removedDuration,
                silenceCutRemovedCount: Array.isArray(cutPlan.removedSilences)
                  ? cutPlan.removedSilences.length
                  : 0,
                finalVideoDuration:
                  activeTool === 'recap'
                    ? prev.finalVideoDuration
                    : cutPlan.trimmedDuration,
              }
            : {
                tool: activeTool,
                segmentCount: finalCaptions.length,
                silenceCutRemovedSeconds: cutPlan.removedDuration,
                silenceCutRemovedCount: Array.isArray(cutPlan.removedSilences)
                  ? cutPlan.removedSilences.length
                  : 0,
                originalVideoDuration: cutPlan.originalDuration,
                aiVoiceDuration: 0,
                finalVideoDuration: cutPlan.trimmedDuration,
                videoPlaybackRate: 1.0,
                voiceSpeed,
              }
        );
      }

      setFinalVideoUrl(renderData.outputVideoUrl ? String(renderData.outputVideoUrl) : null);
      setFinalThumbnailUrl(renderData.thumbnailUrl ? String(renderData.thumbnailUrl) : null);
      setCredits((c) => Math.max(0, c - creditCost));
      setProgress({ step: 4, totalSteps: 4, labelMy: 'ပြီးစီးပါပြီ!', percent: 100 });
      setCurrentStep(6);
      setMaxReachedStep(6);
      showSuccess(`${resolution.toUpperCase()} ဗီဒီယိုနှင့် Viral Thumbnail ဖန်တီးမှု အောင်မြင်စွာ ပြီးဆုံးပါပြီ!`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'လုပ်ငန်းစဉ်အတွင်း အမှားဖြစ်ပွားပါသည်';
      setProcessingError(msg);
      showError(msg);
    } finally {
      setProgress(null);
    }
  };

  const handleSwitchResultThumbnailRatio = async (newRatio: ThumbnailAspectRatio) => {
    setThumbnailAspectRatio(newRatio);
    setThumbnailUpdating(true);
    try {
      const blob = await renderViralThumbnailBlob(
        thumbnailTitle,
        videoUrl,
        newRatio,
        thumbnailAnalysis
      );
      if (!blob) return;
      thumbnailBlobRef.current = blob;
      const form = new FormData();
      form.append('sessionId', sessionId);
      form.append('thumbnailAspectRatio', newRatio);
      form.append('thumbnail', blob, 'thumbnail.jpg');
      const res = await fetch('/api/render-thumbnail', {
        method: 'POST',
        headers: { 'x-session-id': sessionId },
        body: form,
      });
      const data = await parseJsonResponseSafe(res);
      if (res.ok && data.thumbnailUrl) {
        setFinalThumbnailUrl(String(data.thumbnailUrl));
      }
    } catch {
      showError('Thumbnail အချိုးအစား ပြောင်းလဲရာတွင် အမှားဖြစ်ပွားပါသည်');
    } finally {
      setThumbnailUpdating(false);
    }
  };

  const handleSendTelegram = async () => {
    setBanner(null);
    if (!telegramChatId.trim()) {
      showError('Telegram Chat ID ထည့်သွင်းပေးပါ');
      return;
    }
    setTelegramSending(true);
    try {
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          chatId: telegramChatId.trim(),
          resolution,
          thumbnailTitle: truncateThumbnailTitle(thumbnailTitle),
        }),
      });
      const data = await parseJsonResponseSafe(res);
      if (!res.ok) {
        showError(String(data.errorMy || 'Telegram ပေးပို့ရာတွင် အမှားဖြစ်ပွားပါသည်'));
        return;
      }
      showSuccess(String(data.messageMy || 'Telegram သို့ ပေးပို့ပြီးပါပြီ'));
    } catch {
      showError('Telegram Bot နှင့် ချိတ်ဆက်ရာတွင် အမှားဖြစ်ပွားပါသည်');
    } finally {
      setTelegramSending(false);
    }
  };

  const handleStartNew = () => {
    setBanner(null);
    setLinkInput('');
    setVideoUrl(null);
    setVideoTitle('');
    setDurationSeconds(12);
    resetVideoDerivedState();
    setCaptions(INITIAL_CAPTIONS);
    setScriptMy(INITIAL_SCRIPT_MY);
    setCurrentStep(1);
    setMaxReachedStep(1);
  };

  return (
    <div id="studio-top" className="min-h-screen flex flex-col bg-[#090B10] text-slate-100">
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 top-0 h-[420px] bg-[radial-gradient(ellipse_at_top,rgba(59,130,246,0.14),transparent_70%)]"
      />

      <HeaderBar
        credits={credits}
        onOpenCredits={() => setIsCreditModalOpen(true)}
        onOpenDeployGuide={() => setIsDeployModalOpen(true)}
        onGoHome={() => {
          if (currentStep !== 5) setCurrentStep(1);
        }}
      />

      <main className="relative flex-1 mx-auto w-full max-w-[1280px] px-4 py-6 sm:px-6 lg:py-8">
        <WizardStepper
          activeTool={activeTool}
          currentStep={currentStep}
          maxReachedStep={maxReachedStep}
          onSelectStep={(step) => goToStep(step)}
          isProcessing={currentStep === 5 && !processingError}
        />

        {banner && (
          <div
            role="status"
            className={`mx-auto mb-5 flex max-w-4xl items-center gap-3 rounded-xl border px-4 py-3 text-xs sm:text-sm font-medium ${
              banner.type === 'error'
                ? 'border-red-500/40 bg-red-500/10 text-red-200'
                : 'border-blue-500/40 bg-blue-500/12 text-blue-200'
            }`}
          >
            {banner.type === 'error' ? (
              <AlertCircle className="h-4 w-4 text-red-400 shrink-0" />
            ) : (
              <CheckCircle2 className="h-4 w-4 text-blue-400 shrink-0" />
            )}
            <span>{banner.text}</span>
          </div>
        )}

        {/* Active Step View — Strictly One Step at a Time */}
        {currentStep === 1 && (
          <WizardStep1Video
            activeTool={activeTool}
            onChangeTool={(nextTool) => {
              if (nextTool !== activeTool) {
                setActiveTool(nextTool);
                hasUserEditedScriptRef.current = false;
                setTtsAudioUrl(null);
                setSyncSummary(null);
                setTimelineSegments([]);
                setRecapSceneMappings([]);
                setRecapQualityValidation(null);
                setFinalVideoUrl(null);
                setFinalThumbnailUrl(null);
                setProcessingError(null);
              }
            }}
            linkInput={linkInput}
            onChangeLinkInput={setLinkInput}
            onSubmitLink={handleSubmitLink}
            onUploadMp4={handleUploadMp4}
            onLoadSample={handleLoadSample}
            sourceLoading={sourceLoading}
            uploadPercent={uploadPercent}
            videoUrl={videoUrl}
            videoTitle={videoTitle}
            durationSeconds={durationSeconds}
            onNext={() => goToStep(2)}
          />
        )}

        {currentStep === 2 && (
          <WizardStep2Voice
            activeTool={activeTool}
            ttsEngine={ttsEngine}
            onChangeTtsEngine={(nextEngine) => {
              setTtsEngine(nextEngine);
              if (nextEngine === 'edge-tts') {
                setVoiceGender(edgeVoiceId === 'my-MM-ThihaNeural' ? 'male' : 'female');
              }
              setVoicePreviewUrl(null);
              setTtsAudioUrl(null);
            }}
            edgeVoiceId={edgeVoiceId}
            onChangeEdgeVoiceId={(nextId) => {
              setEdgeVoiceId(nextId);
              setVoiceGender(nextId === 'my-MM-ThihaNeural' ? 'male' : 'female');
              setVoicePreviewUrl(null);
              setTtsAudioUrl(null);
            }}
            geminiConfigured={geminiConfigured}
            voiceGender={voiceGender}
            onChangeVoiceGender={(g) => {
              setVoiceGender(g);
              setVoicePreviewUrl(null);
              setTtsAudioUrl(null);
            }}
            voiceStyle={voiceStyle}
            onChangeVoiceStyle={(v) => {
              setVoiceStyle(v);
              setVoicePreviewUrl(null);
              setTtsAudioUrl(null);
            }}
            voiceSpeed={voiceSpeed}
            onChangeVoiceSpeed={(s) => {
              setVoiceSpeed(s);
              setVoicePreviewUrl(null);
              setTtsAudioUrl(null);
            }}
            musicMood={musicMood}
            onChangeMusicMood={setMusicMood}
            sfxEnabled={sfxEnabled}
            onToggleSfx={setSfxEnabled}
            onPreviewVoice={() => void handlePreviewVoice()}
            voicePreviewUrl={voicePreviewUrl}
            voicePreviewLoading={voicePreviewLoading}
            onBack={() => goToStep(1)}
            onNext={() => goToStep(3)}
          />
        )}

        {currentStep === 3 && (
          <WizardStep3PreviewCustomize
            sessionId={sessionId}
            activeTool={activeTool}
            ttsEngine={ttsEngine}
            edgeVoiceId={edgeVoiceId}
            voiceGender={ttsEngine === 'edge-tts' ? (edgeVoiceId === 'my-MM-ThihaNeural' ? 'male' : 'female') : voiceGender}
            voiceStyle={voiceStyle}
            videoUrl={videoUrl}
            videoTitle={videoTitle}
            videoWidth={videoDimensions.width}
            videoHeight={videoDimensions.height}
            durationSeconds={durationSeconds}
            step3Loading={step3Loading}
            step3StatusMy={step3StatusMy}
            step3Error={step3Error}
            sceneProvider={sceneProvider}
            sceneFallbackUsed={sceneFallbackUsed}
            onRetryStep3Analysis={() => void analyzeVideoScenes({ forceRestart: step3Error ? false : true })}
            scenes={scenes}
            storyAnalysisMy={storyAnalysisMy}
            recapSceneMappings={recapSceneMappings}
            recapQualityValidation={recapQualityValidation}
            scriptMy={scriptMy}
            onChangeScriptMy={(val) => {
              hasUserEditedScriptRef.current = true;
              setScriptMy(val);
              setTtsAudioUrl(null);
            }}
            ttsGenerating={ttsGenerating}
            onGenerateAudioPreview={
              activeTool !== 'captions' ? () => void handleGenerateStep3AudioPreview() : undefined
            }
            timelineSegments={timelineSegments}
            onUpdateTimelineSegment={(id, patch) => {
              if (patch.myanmarText !== undefined) {
                hasUserEditedScriptRef.current = true;
                setTtsAudioUrl(null);
              }
              const lockedGender: VoiceGender =
                ttsEngine === 'edge-tts'
                  ? edgeVoiceId === 'my-MM-ThihaNeural'
                    ? 'male'
                    : 'female'
                  : voiceGender || 'female';
              setTimelineSegments((prev) =>
                prev.map((seg) =>
                  seg.id === id
                    ? {
                        ...seg,
                        myanmarText: patch.myanmarText ?? seg.myanmarText,
                        emoji: patch.emoji ?? seg.emoji,
                        voiceGender: seg.kind === 'speaking' ? lockedGender : seg.voiceGender,
                      }
                    : seg
                )
              );
              if (patch.myanmarText !== undefined) {
                const updatedText = patch.myanmarText;
                setCaptions((prev) =>
                  prev.map((cap) =>
                    cap.id === `cap_${id}` || cap.id.startsWith(`cap_${id}_p`)
                      ? { ...cap, text: updatedText }
                      : cap
                  )
                );
              }
            }}
            captions={captions}
            captionsEnabled={captionsEnabled}
            onToggleCaptions={setCaptionsEnabled}
            onUpdateCaption={handleUpdateCaption}
            onNormalizeLongCaptions={handleNormalizeLongCaptions}
            captionStyle={captionStyle}
            onChangeCaptionStyle={setCaptionStyle}
            captionDecoration={captionDecoration}
            onChangeCaptionDecoration={setCaptionDecoration}
            subPos={subPos}
            onChangeSubPos={setSubPos}
            logoUrl={logoPreviewUrl}
            logoEnabled={logoEnabled}
            onToggleLogo={setLogoEnabled}
            logoScale={logoScale}
            onChangeLogoScale={setLogoScale}
            logoPos={logoPos}
            onChangeLogoPos={setLogoPos}
            onUploadLogo={handleUploadLogo}
            autoBlurConfig={autoBlurConfig}
            onChangeAutoBlurConfig={setAutoBlurConfig}
            autoBlurRegions={autoBlurRegions}
            silenceCutPlan={silenceCutPlan}
            silenceDetectLoading={silenceDetectLoading}
            silenceHasAudio={silenceHasAudio}
            ttsAudioUrl={ttsAudioUrl}
            thumbnailTitle={thumbnailTitle}
            onThumbnailCanvasReady={(blob) => {
              thumbnailBlobRef.current = blob;
            }}
            onLoadSample={handleLoadSample}
            sourceLoading={sourceLoading}
            onBack={() => goToStep(2)}
            onNext={() => goToStep(4)}
          />
        )}

        {currentStep === 4 && (
          <WizardStep4Export
            videoUrl={videoUrl}
            resolution={resolution}
            onChangeResolution={setResolution}
            thumbnailTitle={thumbnailTitle}
            onChangeThumbnailTitle={(val) => {
              hasCustomThumbTitleRef.current = true;
              setThumbnailTitle(val);
            }}
            thumbnailAspectRatio={thumbnailAspectRatio}
            onChangeThumbnailAspectRatio={setThumbnailAspectRatio}
            thumbnailAnalysis={thumbnailAnalysis}
            thumbnailAnalyzing={thumbnailAnalyzing}
            onAnalyzeThumbnail={() => {
              hasCustomThumbTitleRef.current = false;
              void analyzeVideoContentThumbnail();
            }}
            onThumbnailCanvasReady={(blob) => {
              thumbnailBlobRef.current = blob;
            }}
            credits={credits}
            creditCost={creditCost}
            onOpenCredits={() => setIsCreditModalOpen(true)}
            onBack={() => goToStep(3)}
            onGenerate={runFullGenerationPipeline}
          />
        )}

        {currentStep === 5 && (
          <WizardStep5Processing
            activeTool={activeTool}
            progress={progress}
            errorText={processingError}
            onRetry={runFullGenerationPipeline}
            onBackToStep4={() => {
              setProcessingError(null);
              goToStep(4);
            }}
          />
        )}

        {currentStep === 6 && (
          <WizardStep6Result
            finalVideoUrl={finalVideoUrl}
            finalThumbnailUrl={finalThumbnailUrl}
            thumbnailTitle={thumbnailTitle}
            thumbnailAspectRatio={thumbnailAspectRatio}
            thumbnailAnalysis={thumbnailAnalysis}
            thumbnailUpdating={thumbnailUpdating}
            onChangeResultThumbnailRatio={(r) => void handleSwitchResultThumbnailRatio(r)}
            resolution={resolution}
            syncSummary={syncSummary}
            scriptMy={scriptMy}
            telegramChatId={telegramChatId}
            onChangeTelegramChatId={setTelegramChatId}
            onSendTelegram={handleSendTelegram}
            telegramSending={telegramSending}
            onBackToEdit={() => goToStep(3)}
            onStartNew={handleStartNew}
          />
        )}
      </main>

      <footer className="border-t border-white/10 py-5 text-xs text-slate-500">
        <div className="mx-auto flex max-w-[1280px] flex-wrap items-center justify-between gap-4 px-4 sm:px-6">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-blue-400 shrink-0" />
            <span>အကောင့်မလို · စာမျက်နှာပိတ်သည်နှင့် ဖိုင်အားလုံး အလိုအလျောက် ဖျက်သိမ်းပေးသည်</span>
          </div>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => setIsCreditModalOpen(true)}
              className="hover:text-slate-200 transition-colors cursor-pointer"
            >
              KBZPay / PromptPay ခရက်ဒစ်
            </button>
            <button
              type="button"
              onClick={() => setIsDeployModalOpen(true)}
              className="hover:text-slate-200 transition-colors cursor-pointer"
            >
              Render & GitHub Pages Deploy လမ်းညွှန်
            </button>
          </div>
        </div>
      </footer>

      <CreditModal
        isOpen={isCreditModalOpen}
        currentCredits={credits}
        onClose={() => setIsCreditModalOpen(false)}
        onSuccessAddCredits={(added, msg) => {
          setCredits((c) => c + added);
          showSuccess(msg);
        }}
      />

      <DeployGuideModal
        isOpen={isDeployModalOpen}
        onClose={() => setIsDeployModalOpen(false)}
      />
    </div>
  );
}
