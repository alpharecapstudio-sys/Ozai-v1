import test from 'node:test';
import assert from 'node:assert/strict';
import {
  assertValidEdgeVoiceId,
  buildAutoBlurFfmpegFilter,
  buildTtsVoicePersonaDirective,
  calculateCreditCost,
  CAPTION_BOTTOM_SAFETY_MARGIN_PCT,
  CAPTION_BOX_MAX_WIDTH_PCT,
  CAPTION_LINE_HEIGHT,
  clampOverlayPosition,
  clampPointerToVideoViewport,
  computeContainedVideoRect,
  computeUploadChunkPlan,
  countCharacters,
  DEFAULT_AUTO_BLUR_CONFIG,
  DEFAULT_CAPTION_DECORATION,
  DEFAULT_EDGE_VOICE_ID,
  DEFAULT_TTS_ENGINE,
  detectStaticOverlayRegionsFromPpmFrames,
  EDGE_BURMESE_VOICES,
  enforceSingleVoiceForDubbingSegments,
  extractMediaDurationSeconds,
  formatSrtTime,
  formatTimecode,
  formatVoiceGenderLabelMy,
  formatVoiceSpeedLabel,
  GEMINI_FREE_VOICES,
  generateAssSubtitles,
  generateSrtSubtitles,
  getActiveCaptionAtTime,
  getGeminiFreeVoice,
  getVoiceSpeedFactor,
  hexToAssColor,
  hexToRgba,
  isAudibleNonSilentStats,
  normalizeMyanmarVoiceId,
  normalizeTtsEngineId,
  normalizeVoiceGender,
  normalizeVoiceSpeed,
  parseDurationTagToSeconds,
  parseFfmpegVolumeStats,
  parseJsonResponseSafe,
  parseVoiceSpeedInput,
  resolveCaptionsEnabledFlag,
  resolveEdgeVoiceForGender,
  sanitizeAutoBlurConfig,
  sanitizeAutoBlurRegions,
  sanitizeCaptionDecoration,
  sanitizeTtsSpeechText,
  shouldBurnSubtitlesInRender,
  splitLongCaptionsToMaxTwoLines,
  splitScriptIntoTimedCaptions,
  splitTextIntoTtsChunks,
  truncateThumbnailTitle,
  UPLOAD_CHUNK_SIZE_BYTES,
  validateEdgeTtsInputText,
  validateUploadFileSize,
  validateVideoDuration,
  validateVideoUrl,
  validateVoiceGenderForTool,
  VOICE_SPEED_STEPS,
  wrapCaptionTextToLines,
  wrapWavHeaderIfNeeded,
} from './studioLogic';

test('validateVideoUrl accepts supported public platforms and rejects unsupported links', () => {
  assert.deepEqual(validateVideoUrl('https://www.youtube.com/watch?v=dQw4w9WgXcQ'), {
    valid: true,
    platform: 'YouTube',
  });
  assert.deepEqual(validateVideoUrl('https://youtu.be/abc123'), {
    valid: true,
    platform: 'YouTube',
  });
  assert.deepEqual(validateVideoUrl('https://www.tiktok.com/@movie/video/12345'), {
    valid: true,
    platform: 'TikTok',
  });
  assert.deepEqual(validateVideoUrl('https://fb.watch/xyz99/'), {
    valid: true,
    platform: 'Facebook',
  });
  assert.deepEqual(validateVideoUrl('https://www.instagram.com/reel/C9abc/'), {
    valid: true,
    platform: 'Instagram',
  });

  const invalid = validateVideoUrl('https://vimeo.com/12345');
  assert.equal(invalid.valid, false);
  assert.ok(invalid.errorMy);

  const empty = validateVideoUrl('   ');
  assert.equal(empty.valid, false);
});

test('validateVideoDuration enforces maximum 120 minutes (7200 seconds)', () => {
  assert.equal(validateVideoDuration(120).valid, true);
  assert.equal(validateVideoDuration(7200).valid, true);
  assert.equal(validateVideoDuration(7201).valid, false);
  assert.equal(validateVideoDuration(0).valid, false);
  assert.equal(validateVideoDuration(-10).valid, false);
});

test('clampOverlayPosition keeps dragged captions and logos within 8%-92% bounds', () => {
  assert.deepEqual(clampOverlayPosition(-5, 110), { x: 8, y: 92 });
  assert.deepEqual(clampOverlayPosition(52.34, 81.26), { x: 52.3, y: 81.3 });
});

test('truncateThumbnailTitle enforces strictly under 25 characters without splitting graphemes', () => {
  const short = 'လူသတ်သမားဘယ်သူလဲ';
  assert.equal(truncateThumbnailTitle(short), short);
  assert.ok(countCharacters(short) < 25);

  const longTitle = 'ဒီဇာတ်ကားရဲ့ နောက်ဆုံးအလှည့်အပြောင်းက အရမ်းကြောက်စရာကောင်းတယ်';
  const truncated = truncateThumbnailTitle(longTitle);
  assert.ok(countCharacters(truncated) < 25);
});

test('calculateCreditCost computes deterministic tool + 4K + long duration pricing', () => {
  assert.equal(calculateCreditCost('recap', false, 600), 10);
  assert.equal(calculateCreditCost('recap', true, 600), 14);
  assert.equal(calculateCreditCost('dubbing', false, 600), 8);
  assert.equal(calculateCreditCost('captions', true, 600), 9);
  assert.equal(calculateCreditCost('recap', false, 2400), 20);
});

test('getVoiceSpeedFactor, normalizeVoiceSpeed, formatVoiceSpeedLabel and VOICE_SPEED_STEPS behave accurately', () => {
  assert.deepEqual([...VOICE_SPEED_STEPS], [1.0, 1.2, 1.4, 1.6, 1.8, 2.0]);
  assert.equal(getVoiceSpeedFactor('slow'), 0.85);
  assert.equal(getVoiceSpeedFactor('normal'), 1.0);
  assert.equal(getVoiceSpeedFactor('fast'), 1.22);
  assert.equal(getVoiceSpeedFactor('2x'), 2.0);
  for (const step of VOICE_SPEED_STEPS) {
    assert.equal(normalizeVoiceSpeed(step), step);
    assert.equal(getVoiceSpeedFactor(step), step);
    assert.equal(formatVoiceSpeedLabel(step), `${step.toFixed(1)}x`);
  }
  assert.equal(normalizeVoiceSpeed(2.5), 2.0);
  assert.equal(normalizeVoiceSpeed(0.4), 1.0);
  assert.equal(parseVoiceSpeedInput('slow'), 'slow');
  assert.equal(parseVoiceSpeedInput('normal'), 'normal');
  assert.equal(parseVoiceSpeedInput('fast'), 'fast');
  assert.equal(parseVoiceSpeedInput('2x'), 2.0);
  assert.equal(parseVoiceSpeedInput(1.6), 1.6);
  assert.equal(formatVoiceSpeedLabel('slow'), 'Slow (0.85x)');
  assert.equal(formatVoiceSpeedLabel('normal'), 'Normal (1.0x)');
  assert.equal(formatVoiceSpeedLabel('fast'), 'Fast (1.2x)');
  assert.equal(formatTimecode(65), '01:05');
  assert.equal(formatTimecode(3665), '01:01:05');
});

test('getActiveCaptionAtTime finds matching segment for timestamp', () => {
  const segments = [
    { id: '1', start: 0, end: 3.5, text: 'အစပိုင်း', emoji: '🎬' },
    { id: '2', start: 3.6, end: 7.0, text: 'အလှည့်အပြောင်း', emoji: '😱' },
  ];
  assert.equal(getActiveCaptionAtTime(segments, 2.0)?.id, '1');
  assert.equal(getActiveCaptionAtTime(segments, 5.2)?.id, '2');
  assert.equal(getActiveCaptionAtTime(segments, 8.0), null);
});

test('wrapWavHeaderIfNeeded adds RIFF header only when missing', () => {
  const rawPcm = new Uint8Array([1, 2, 3, 4]);
  const wrapped = wrapWavHeaderIfNeeded(rawPcm);
  assert.equal(wrapped.length, 48);
  assert.equal(String.fromCharCode(...wrapped.slice(0, 4)), 'RIFF');

  const alreadyWav = wrapWavHeaderIfNeeded(wrapped);
  assert.equal(alreadyWav.length, 48);
});

test('generateAssSubtitles produces positioned ASS dialogue events', () => {
  const ass = generateAssSubtitles(
    [{ id: '1', start: 0.5, end: 3.2, text: 'စုံထောက်ကြီး ရောက်လာပြီ', emoji: '🔥' }],
    1920,
    1080,
    { x: 50, y: 80 }
  );
  assert.ok(ass.includes('PlayResX: 1920'));
  assert.ok(ass.includes('\\pos(960,864)'));
  assert.ok(ass.includes('စုံထောက်ကြီး ရောက်လာပြီ 🔥'));
});

test('computeUploadChunkPlan splits files larger than 4MB into chunked uploads safe for Cloud Run 32MB cap', () => {
  const small = computeUploadChunkPlan(2 * 1024 * 1024);
  assert.equal(small.useChunked, false);
  assert.equal(small.totalChunks, 1);

  const large = computeUploadChunkPlan(45 * 1024 * 1024);
  assert.equal(large.useChunked, true);
  assert.equal(large.chunkSizeBytes, UPLOAD_CHUNK_SIZE_BYTES);
  assert.equal(large.totalChunks, 12);

  assert.equal(validateUploadFileSize(0).valid, false);
  assert.equal(validateUploadFileSize(10 * 1024 * 1024).valid, true);
  assert.equal(validateUploadFileSize(3 * 1024 * 1024 * 1024).valid, false);
});

test('extractMediaDurationSeconds parses format, stream, and HH:MM:SS.ms tag durations accurately', () => {
  assert.equal(parseDurationTagToSeconds('00:01:23.50'), 83.5);
  assert.equal(
    extractMediaDurationSeconds({
      format: { duration: '0' },
      streams: [{ codec_type: 'video', tags: { DURATION: '00:02:10.25' } }],
    }),
    130.25
  );
  assert.equal(
    extractMediaDurationSeconds({
      format: { duration: '15.4' },
      streams: [{ codec_type: 'audio', duration: '15.2' }],
    }),
    15.4
  );
});

test('computeContainedVideoRect preserves portrait 9:16 and ultrawide aspect ratios without stretching', () => {
  // Portrait 1080x1920 video inside a 800x450 landscape stage -> pillarboxed cleanly
  const portrait = computeContainedVideoRect(800, 450, 1080, 1920);
  assert.equal(portrait.height, 450);
  assert.equal(portrait.width, 253); // 450 * (1080 / 1920) = 253.125
  assert.ok(Math.abs(portrait.width / portrait.height - 9 / 16) < 0.01);

  // Square 1080x1080 inside 800x450
  const square = computeContainedVideoRect(800, 450, 1080, 1080);
  assert.equal(square.width, 450);
  assert.equal(square.height, 450);

  // Wide 21:9 (2520x1080) inside 800x450
  const wide = computeContainedVideoRect(800, 450, 2520, 1080);
  assert.equal(wide.width, 800);
  assert.equal(wide.height, 343);
});

test('clampPointerToVideoViewport constrains dragged captions/logos strictly inside rendered video bounds', () => {
  // Rendered portrait video box sits centered at left=273, width=253, height=450
  const videoBox = { left: 273, top: 100, width: 253, height: 450 };

  // Pointer dragged far outside left edge into black pillarbox -> clamped strictly inside video box!
  const leftEdge = clampPointerToVideoViewport({
    clientX: 50,
    clientY: 325,
    rect: videoBox,
    overlayWidthPx: 100,
    overlayHeightPx: 40,
  });
  // halfWPct = (100 / 253) * 50 = 19.76% -> clamped >= 19.8%
  assert.ok(leftEdge.x >= 19.5 && leftEdge.x <= 20.5);
  assert.equal(leftEdge.y, 50);

  // Pointer dragged past bottom edge -> clamped cleanly inside bottom bound
  const bottomEdge = clampPointerToVideoViewport({
    clientX: 400,
    clientY: 999,
    rect: videoBox,
    overlayWidthPx: 100,
    overlayHeightPx: 45,
  });
  assert.ok(bottomEdge.y <= 95.5);
  assert.ok(bottomEdge.y >= 94.0);
});

test('sanitizeCaptionDecoration clamps styling values and hexToAssColor/hexToRgba format accurately', () => {
  const sanitized = sanitizeCaptionDecoration({
    fontSizePreset: 'large',
    fontSizeScale: 2.5,
    textColor: '#facc15',
    borderEnabled: true,
    borderThickness: 18,
    borderColor: '#ef4444',
    blurBgEnabled: true,
    blurIntensity: 40,
    bgOpacity: 150,
    bgCornerRadius: -4,
  });
  assert.equal(sanitized.fontSizeScale, 1.7);
  assert.equal(sanitized.textColor, '#FACC15');
  assert.equal(sanitized.borderThickness, 10);
  assert.equal(sanitized.borderColor, '#EF4444');
  assert.equal(sanitized.blurIntensity, 24);
  assert.equal(sanitized.bgOpacity, 100);
  assert.equal(sanitized.bgCornerRadius, 0);

  assert.equal(hexToRgba('#090B10', 50), 'rgba(9, 11, 16, 0.5)');
  // ASS uses &HAABBGGRR (00=opaque, FF=transparent)
  assert.equal(hexToAssColor('#FF0000', 100), '&H000000FF');
  assert.equal(hexToAssColor('#00FF00', 0), '&HFF00FF00');
});

test('generateAssSubtitles applies custom text color, outline toggle/thickness, and background mask layer', () => {
  const styledAss = generateAssSubtitles(
    [{ id: '1', start: 0.5, end: 3.0, text: 'စာတန်းအလှဆင်', emoji: '✨' }],
    1080,
    1920,
    { x: 50, y: 80 },
    {
      ...DEFAULT_CAPTION_DECORATION,
      fontSizePreset: 'large',
      fontSizeScale: 1.4,
      textColor: '#FACC15',
      borderEnabled: true,
      borderThickness: 6,
      borderColor: '#EF4444',
      blurBgEnabled: false,
    }
  );
  // 1920 * 0.045 * 1.4 = 120.96 -> 121px font size
  assert.ok(styledAss.includes('Style: RecapMain,Noto Sans Myanmar,121,&H0015CCFA,&H003B82F6,&H004444EF'));
  assert.ok(styledAss.includes(',1,6,1,5,'));
  assert.equal(styledAss.includes('Dialogue: 0,'), false); // background mask toggled OFF

  const withMask = generateAssSubtitles(
    [{ id: '1', start: 0.5, end: 3.0, text: 'စာတန်းအလှဆင်', emoji: '✨' }],
    1080,
    1920,
    { x: 50, y: 80 },
    {
      ...DEFAULT_CAPTION_DECORATION,
      borderEnabled: false,
      blurBgEnabled: true,
      bgOpacity: 60,
      bgColor: '#090B10',
    }
  );
  assert.ok(withMask.includes('Dialogue: 0,')); // semi-transparent bg mask enabled
  assert.ok(withMask.includes(',1,0,0,5,')); // border disabled -> outline=0
});

test('Long caption readability: enforces 70%-75% width, comfortable line height, max 2 lines, auto-splits with new timestamps, and respects 8%-10% bottom margin', () => {
  assert.ok(CAPTION_BOX_MAX_WIDTH_PCT >= 70 && CAPTION_BOX_MAX_WIDTH_PCT <= 75);
  assert.ok(CAPTION_LINE_HEIGHT >= 1.4 && CAPTION_LINE_HEIGHT <= 1.6);
  assert.ok(CAPTION_BOTTOM_SAFETY_MARGIN_PCT >= 8 && CAPTION_BOTTOM_SAFETY_MARGIN_PCT <= 10);

  const lines = wrapCaptionTextToLines(
    'Detective walks carefully through the pouring midnight rain toward the abandoned warehouse door looking for hidden evidence',
    22
  );
  assert.ok(lines.length >= 4);
  for (const line of lines) {
    assert.ok(line.length <= 22);
  }

  // Automatic split into separate captions with sequential timestamps when exceeding 2 lines
  const split = splitLongCaptionsToMaxTwoLines(
    [
      {
        id: 'cap_long',
        start: 1.0,
        end: 7.0,
        text: 'မိုးရွာနေတဲ့ညမှာ စုံထောက်ကြီး တစ်ယောက်တည်း တံတားပေါ်ကနေ ဆင်းလာပြီး နောက်ကွယ်က လျှို့ဝှက်ချက်ကြီးကို ဖော်ထုတ်ဖို့ အရမ်းအရေးကြီးတဲ့ သဲလွန်စတစ်ခုကို ရှာဖွေနေခဲ့တယ်',
        emoji: '🌧️',
      },
    ],
    { maxCharsPerLine: 22 }
  );
  assert.ok(split.length >= 2);
  assert.equal(split[0].start, 1.0);
  assert.equal(split[split.length - 1].end, 7.0);
  for (let i = 0; i < split.length; i++) {
    const lineCount = split[i].text.split('\n').length;
    assert.ok(lineCount >= 1 && lineCount <= 2, `Chunk ${i} exceeded 2 lines: ${lineCount}`);
    assert.ok(split[i].end > split[i].start);
    if (i > 0) {
      assert.equal(split[i].start, split[i - 1].end);
    }
  }

  // Bottom safety margin 9% prevents caption box bottom edge from reaching bottom 0%-8%
  const vpBox = { left: 0, top: 0, width: 800, height: 500 };
  const clamped = clampPointerToVideoViewport({
    clientX: 400,
    clientY: 495,
    rect: vpBox,
    overlayWidthPx: 560, // 70% width
    overlayHeightPx: 50, // halfHeight = 5%
    bottomSafetyMarginPct: CAPTION_BOTTOM_SAFETY_MARGIN_PCT, // 9%
    sideSafetyMarginPct: 4,
  });
  // Max center Y = 100 - 5 - 9 = 86% -> bottom edge sits at 86% + 5% = 91% (9% bottom margin!)
  assert.ok(clamped.y <= 86.1, `Expected Y <= 86%, got ${clamped.y}%`);
  assert.equal(clamped.x, 50);

  // ASS subtitles encode 72% box width (14% side margins) and split overly long captions into <=2 lines per Dialogue
  const assOut = generateAssSubtitles(
    [
      {
        id: 'cap_long',
        start: 0.5,
        end: 6.5,
        text: 'One very long sentence that definitely wraps across four separate lines inside a video subtitle box without shrinking',
        emoji: '🎬',
      },
    ],
    1920,
    1080,
    { x: 50, y: 95 }, // pushed toward bottom -> should clamp cleanly above bottom 9% safety zone
    DEFAULT_CAPTION_DECORATION
  );
  // 1920 * 0.14 = 269 margin left/right
  assert.ok(assOut.includes(',5,269,269,97,1'));
  // Multiple Dialogue layer 1 events created cleanly for split caption parts
  const mainDialogues = assOut.split('\n').filter((l) => l.startsWith('Dialogue: 1,'));
  assert.ok(mainDialogues.length >= 2);
});

test('Male/Female AI voice gender selection is required for Movie Recap & Myanmar Dubbing and excluded for Captions Only', () => {
  assert.equal(normalizeVoiceGender('male'), 'male');
  assert.equal(normalizeVoiceGender('FEMALE'), 'female');
  assert.equal(normalizeVoiceGender(''), null);
  assert.equal(normalizeVoiceGender(null), null);

  // Required for recap and dubbing
  assert.equal(validateVoiceGenderForTool('recap', null).valid, false);
  assert.equal(validateVoiceGenderForTool('dubbing', undefined).valid, false);
  assert.deepEqual(validateVoiceGenderForTool('recap', 'male'), { valid: true, gender: 'male' });
  assert.deepEqual(validateVoiceGenderForTool('dubbing', 'female'), { valid: true, gender: 'female' });

  // Not required / excluded for captions-only
  assert.deepEqual(validateVoiceGenderForTool('captions', null), { valid: true, gender: null });

  assert.equal(formatVoiceGenderLabelMy('male'), 'အမျိုးသားအသံ (Thiha · Male)');
  assert.equal(formatVoiceGenderLabelMy('female'), 'အမျိုးသမီးအသံ (Nilar · Female)');

  assert.ok(buildTtsVoicePersonaDirective('male', 'street_bro').includes('MALE'));
  assert.ok(buildTtsVoicePersonaDirective('female', 'thriller_narrator').includes('FEMALE'));

  // Expanded Free Gemini AI Voice library validation (10 distinct voices × Male & Female = 20 vocal styles)
  assert.ok(GEMINI_FREE_VOICES.length >= 10);
  const uniqueVoiceIds = new Set(GEMINI_FREE_VOICES.map((v) => v.id));
  assert.equal(uniqueVoiceIds.size, GEMINI_FREE_VOICES.length);
  assert.equal(normalizeMyanmarVoiceId('horror_whisper'), 'horror_whisper');
  assert.equal(normalizeMyanmarVoiceId('unknown_voice'), 'street_bro');

  for (const voice of GEMINI_FREE_VOICES) {
    assert.ok(voice.nameMy.trim().length > 0);
    assert.ok(voice.descMy.trim().length > 0);
    assert.ok(voice.sampleTextMy.trim().length > 0);
    assert.equal(getGeminiFreeVoice(voice.id).id, voice.id);
    const maleDir = buildTtsVoicePersonaDirective('male', voice.id);
    const femaleDir = buildTtsVoicePersonaDirective('female', voice.id);
    assert.ok(maleDir.includes('MALE'));
    assert.ok(femaleDir.includes('FEMALE'));
    assert.notEqual(maleDir, femaleDir);
  }
});

test('Auto Blur Mask: sanitizes config/regions inside video bounds and builds blur/pixelate/solid FFmpeg filters', () => {
  const cfg = sanitizeAutoBlurConfig({ enabled: true, strength: 200, style: 'pixelate', solidColor: '#123' });
  assert.equal(cfg.enabled, true);
  assert.equal(cfg.strength, 100);
  assert.equal(cfg.style, 'pixelate');
  assert.equal(cfg.solidColor, '#112233');

  const invalidCfg = sanitizeAutoBlurConfig({ style: 'unknown' as never, strength: -5, enabled: false });
  assert.equal(invalidCfg.style, DEFAULT_AUTO_BLUR_CONFIG.style);
  assert.equal(invalidCfg.strength, 10);
  assert.equal(invalidCfg.enabled, false);

  // Clamp coordinates strictly within [0..100] of original video resolution
  const regions = sanitizeAutoBlurRegions([
    { id: 'wm', xPct: -10, yPct: 4, widthPct: 22, heightPct: 12, kind: 'watermark' },
    { id: 'sub', xPct: 80, yPct: 85, widthPct: 40, heightPct: 30, kind: 'text' },
    { id: 'tiny', xPct: 10, yPct: 10, widthPct: 0.5, heightPct: 1, kind: 'logo' },
  ]);
  assert.equal(regions.length, 2);
  assert.equal(regions[0].xPct, 0);
  assert.ok(regions[1].xPct + regions[1].widthPct <= 100);
  assert.ok(regions[1].yPct + regions[1].heightPct <= 100);

  // Disabled -> empty FFmpeg filter
  assert.deepEqual(
    buildAutoBlurFfmpegFilter({
      inputLabel: '[0:v]',
      outputLabel: '[v_blurred]',
      videoWidth: 1280,
      videoHeight: 720,
      regions,
      config: { ...DEFAULT_AUTO_BLUR_CONFIG, enabled: false },
    }),
    []
  );

  // Blur filter uses boxblur + overlay
  const blurFilters = buildAutoBlurFfmpegFilter({
    inputLabel: '[0:v]',
    outputLabel: '[v_blurred]',
    videoWidth: 1280,
    videoHeight: 720,
    regions,
    config: { enabled: true, strength: 80, style: 'blur', solidColor: '#090B10' },
  });
  assert.ok(blurFilters.some((f) => f.includes('boxblur=')));
  assert.ok(blurFilters.some((f) => f.includes('overlay=') && f.endsWith('[v_blurred]')));

  // Pixelate filter uses neighbor scale down/up + overlay
  const pixFilters = buildAutoBlurFfmpegFilter({
    inputLabel: '[0:v]',
    outputLabel: '[v_blurred]',
    videoWidth: 1280,
    videoHeight: 720,
    regions,
    config: { enabled: true, strength: 70, style: 'pixelate', solidColor: '#090B10' },
  });
  assert.ok(pixFilters.some((f) => f.includes('flags=neighbor')));

  // Solid filter uses drawbox=t=fill
  const solidFilters = buildAutoBlurFfmpegFilter({
    inputLabel: '[0:v]',
    outputLabel: '[v_blurred]',
    videoWidth: 1280,
    videoHeight: 720,
    regions,
    config: { enabled: true, strength: 100, style: 'solid', solidColor: '#000000' },
  });
  assert.equal(solidFilters.length, 1);
  assert.ok(solidFilters[0].includes('drawbox=') && solidFilters[0].includes('t=fill'));
});

test('detectStaticOverlayRegionsFromPpmFrames detects static high-contrast corner watermark across frames and skips clean backgrounds', () => {
  const makePpm = (drawWatermark: boolean, bgShift: number) => {
    const w = 160;
    const h = 90;
    const header = Buffer.from(`P6\n${w} ${h}\n255\n`, 'ascii');
    const rgb = Buffer.alloc(w * h * 3);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const idx = (y * w + x) * 3;
        const base = (30 + bgShift + Math.round((x + y) * 0.15)) & 0xff;
        rgb[idx] = base;
        rgb[idx + 1] = base;
        rgb[idx + 2] = base;
        if (drawWatermark && x >= 122 && x <= 156 && y >= 4 && y <= 16) {
          // Sharp static checkerboard logo text
          const fg = (x + y) % 2 === 0 ? 250 : 12;
          rgb[idx] = fg;
          rgb[idx + 1] = fg;
          rgb[idx + 2] = fg;
        }
      }
    }
    return Buffer.concat([header, rgb]);
  };

  // Clean moving frames -> no spurious mask regions
  const cleanRegions = detectStaticOverlayRegionsFromPpmFrames([
    makePpm(false, 0),
    makePpm(false, 25),
    makePpm(false, 50),
  ]);
  assert.equal(cleanRegions.length, 0);

  // Frames with static top-right watermark on moving background -> detects top-right region
  const wmRegions = detectStaticOverlayRegionsFromPpmFrames([
    makePpm(true, 0),
    makePpm(true, 25),
    makePpm(true, 50),
  ]);
  assert.ok(wmRegions.length >= 1);
  assert.ok(wmRegions.some((r) => r.xPct >= 65 && r.yPct <= 20));
});

test('buildAutoBlurFfmpegFilter clamps luma/chroma boxblur radii for narrow portrait and landscape crops (prevents FFmpeg -22 EINVAL)', () => {
  // Reproduces real crash #1: portrait 720x1280 with crop ~90x142 at x=90, y=0 and strength=100
  const portraitNarrow = buildAutoBlurFfmpegFilter({
    inputLabel: '[0:v]',
    outputLabel: '[v_blurred]',
    videoWidth: 720,
    videoHeight: 1280,
    regions: [
      { id: 'p1', xPct: 12.5, yPct: 0, widthPct: 12.5, heightPct: 11.1, kind: 'text' },
    ],
    config: { enabled: true, strength: 100, style: 'blur', solidColor: '#090B10' },
  });
  assert.ok(portraitNarrow.length > 0);
  const portraitBoxblur = portraitNarrow.find((f) => f.includes('boxblur=')) || '';
  assert.ok(portraitBoxblur.includes('format=yuv420p,boxblur='));
  assert.ok(portraitBoxblur.includes('floor(min(cw,ch)/2)-1'));
  // Extract static chroma bound from chroma_radius='max(0,min(<N>,...))' -> <= floor(90/4)-1 = 21
  const pChromaMatch = portraitBoxblur.match(/chroma_radius='max\(0,min\((\d+),/);
  assert.ok(pChromaMatch, `Expected clamped chroma_radius expression in: ${portraitBoxblur}`);
  assert.ok(Number(pChromaMatch![1]) <= Math.floor(90 / 4) - 1);

  // Reproduces real crash #2: 1280x720 with narrow vertical strip crop ~50x346 at right edge and high strength
  const landscapeStrip = buildAutoBlurFfmpegFilter({
    inputLabel: '[v_timed]',
    outputLabel: '[v_blurred]',
    videoWidth: 1280,
    videoHeight: 720,
    regions: [
      { id: 'l1', xPct: 95.9, yPct: 5, widthPct: 4.0, heightPct: 48, kind: 'watermark' },
    ],
    config: { enabled: true, strength: 65, style: 'blur', solidColor: '#090B10' },
  });
  const stripBoxblur = landscapeStrip.find((f) => f.includes('boxblur=')) || '';
  const sChromaMatch = stripBoxblur.match(/chroma_radius='max\(0,min\((\d+),/);
  assert.ok(sChromaMatch, `Expected clamped chroma_radius expression in: ${stripBoxblur}`);
  // For w=50 (or 52): max chroma radius <= floor(52/4)-1 = 12 (never 20!)
  assert.ok(Number(sChromaMatch![1]) <= 12);

  // Tiny 8x8 corner-clamped edge crop must still stay valid (maxLuma=3, maxChroma=1)
  const tinyFilters = buildAutoBlurFfmpegFilter({
    inputLabel: '[0:v]',
    outputLabel: '[v_blurred]',
    videoWidth: 200,
    videoHeight: 200,
    regions: [{ id: 'tiny', xPct: 96, yPct: 96, widthPct: 4, heightPct: 4, kind: 'logo' }],
    config: { enabled: true, strength: 100, style: 'blur', solidColor: '#090B10' },
  });
  const tinyBoxblur = tinyFilters.find((f) => f.includes('boxblur=')) || '';
  const tinyLumaMatch = tinyBoxblur.match(/luma_radius='min\((\d+),/);
  const tinyChromaMatch = tinyBoxblur.match(/chroma_radius='max\(0,min\((\d+),/);
  assert.ok(tinyLumaMatch && Number(tinyLumaMatch[1]) <= 3, `Expected tiny luma <= 3 in: ${tinyBoxblur}`);
  assert.ok(tinyChromaMatch && Number(tinyChromaMatch[1]) <= 1, `Expected tiny chroma <= 1 in: ${tinyBoxblur}`);
});

test('formatSrtTime and generateSrtSubtitles produce valid UTF-8 SRT cues with preserved originalText on two-line splits', () => {
  assert.equal(formatSrtTime(0), '00:00:00,000');
  assert.equal(formatSrtTime(65.432), '00:01:05,432');

  const splitWithOrig = splitLongCaptionsToMaxTwoLines(
    [
      {
        id: 'sub_1',
        start: 1.0,
        end: 7.0,
        text: 'မိုးရွာနေတဲ့ညမှာ စုံထောက်ကြီး တစ်ယောက်တည်း တံတားပေါ်ကနေ ဆင်းလာပြီး အလွန်အရေးကြီးတဲ့ သဲလွန်စကို ရှာတွေ့သွားတယ်',
        emoji: '💬',
        originalText: 'Detective walked down the bridge in the pouring rain and found the clue.',
      },
    ],
    { maxCharsPerLine: 22 }
  );
  assert.ok(splitWithOrig.length >= 2);
  assert.equal(
    splitWithOrig[0].originalText,
    'Detective walked down the bridge in the pouring rain and found the clue.'
  );

  const srt = generateSrtSubtitles(splitWithOrig);
  assert.ok(srt.includes('1\n00:00:01,000 --> '));
  assert.ok(srt.includes('💬'));
  assert.ok(srt.includes('2\n'));
});

test('splitScriptIntoTimedCaptions splits edited Myanmar recap script sequentially across video duration', () => {
  const editedScript =
    'ပထမဆုံး စုံထောက်ကြီးက မိုးရွာထဲမှာ ရောက်လာတယ်။ ဒုတိယအချက် သံသယဖြစ်စရာ လူတစ်ယောက် ထွက်ပြေးသွားတယ်။ နောက်ဆုံး အဖြစ်မှန်ပေါ်သွားပြီ။';
  const caps = splitScriptIntoTimedCaptions(editedScript, 9.0);
  assert.equal(caps.length, 3);
  assert.equal(caps[0].start, 0);
  assert.equal(caps[caps.length - 1].end, 9);
  for (let i = 1; i < caps.length; i++) {
    assert.equal(caps[i].start, caps[i - 1].end);
    assert.ok(caps[i].end > caps[i].start);
  }
});

test('resolveCaptionsEnabledFlag & shouldBurnSubtitlesInRender respect ON/OFF states cleanly', () => {
  assert.equal(resolveCaptionsEnabledFlag(undefined), true);
  assert.equal(resolveCaptionsEnabledFlag(''), true);
  assert.equal(resolveCaptionsEnabledFlag(true), true);
  assert.equal(resolveCaptionsEnabledFlag('true'), true);
  assert.equal(resolveCaptionsEnabledFlag('ON'), true);
  assert.equal(resolveCaptionsEnabledFlag(false), false);
  assert.equal(resolveCaptionsEnabledFlag('false'), false);
  assert.equal(resolveCaptionsEnabledFlag('OFF'), false);
  assert.equal(resolveCaptionsEnabledFlag('0'), false);

  const sampleCaps = [{ id: 'c1', start: 0, end: 2, text: 'မင်္ဂလာပါ', emoji: '🎬' }];
  assert.equal(shouldBurnSubtitlesInRender(true, sampleCaps), true);
  assert.equal(shouldBurnSubtitlesInRender(false, sampleCaps), false);
  assert.equal(shouldBurnSubtitlesInRender(true, []), false);
  assert.equal(
    shouldBurnSubtitlesInRender(true, [{ id: 'c2', start: 0, end: 2, text: '   ', emoji: '' }]),
    false
  );
});

test('Edge Burmese Neural TTS engine defaults to Nilar, locks single dubbing voice, and rejects silent/fake audio', () => {
  assert.equal(DEFAULT_TTS_ENGINE, 'edge-tts');
  assert.equal(DEFAULT_EDGE_VOICE_ID, 'my-MM-NilarNeural');
  assert.equal(EDGE_BURMESE_VOICES['my-MM-NilarNeural'].gender, 'female');
  assert.equal(EDGE_BURMESE_VOICES['my-MM-ThihaNeural'].gender, 'male');
  assert.equal(normalizeTtsEngineId(undefined), 'edge-tts');
  assert.equal(normalizeTtsEngineId('gemini-tts'), 'gemini-tts');
  assert.equal(resolveEdgeVoiceForGender(null), 'my-MM-NilarNeural');
  assert.equal(resolveEdgeVoiceForGender('male'), 'my-MM-ThihaNeural');
  assert.equal(resolveEdgeVoiceForGender('male', 'my-MM-NilarNeural'), 'my-MM-NilarNeural');
  assert.throws(() => assertValidEdgeVoiceId('en-US-AriaNeural'), /Unsupported Edge Burmese voice ID/);

  // Single-voice lock across all dubbing segments
  const locked = enforceSingleVoiceForDubbingSegments(
    [
      {
        id: 'seg_1',
        kind: 'speaking',
        start: 0,
        end: 3,
        duration: 3,
        text: 'Hello',
        myanmarText: 'မင်္ဂလာပါ',
        emoji: '🎬',
        voiceGender: 'male',
        aiVoiceDuration: 0,
        setptsFactor: 1,
        videoPlaybackRate: 1,
        outputStart: 0,
        outputEnd: 3,
      },
      {
        id: 'seg_2',
        kind: 'silence',
        start: 3,
        end: 5,
        duration: 2,
        text: '',
        myanmarText: '',
        emoji: '',
        voiceGender: 'male',
        aiVoiceDuration: 0,
        setptsFactor: 1,
        videoPlaybackRate: 1,
        outputStart: 3,
        outputEnd: 5,
      },
    ],
    'female'
  );
  assert.equal(locked[0].voiceGender, 'female');
  assert.equal(locked[1].voiceGender, undefined);

  // Input validation & non-silent audio checks
  assert.equal(validateEdgeTtsInputText('  မင်္ဂလာပါ\nခင်ဗျာ  '), 'မင်္ဂလာပါ ခင်ဗျာ');
  assert.throws(() => validateEdgeTtsInputText('... ။  '), /TTS စာသား/);

  const audibleStats = parseFfmpegVolumeStats(
    '[Parsed_volumedetect_0] mean_volume: -21.1 dB\n[Parsed_volumedetect_0] max_volume: -4.6 dB'
  );
  assert.equal(isAudibleNonSilentStats(audibleStats, 4.2).valid, true);

  const silentStats = parseFfmpegVolumeStats(
    '[Parsed_volumedetect_0] mean_volume: -inf dB\n[Parsed_volumedetect_0] max_volume: -inf dB'
  );
  assert.equal(isAudibleNonSilentStats(silentStats, 3.0).valid, false);
  assert.equal(isAudibleNonSilentStats(audibleStats, 0.05).valid, false);
});

test('sanitizeTtsSpeechText & splitTextIntoTtsChunks strip non-speech stage cues/emojis and safely chunk long Burmese narration', () => {
  assert.equal(sanitizeTtsSpeechText('[Music] (applause) 🔥 ... ။'), '');
  assert.equal(
    sanitizeTtsSpeechText('  [sighs] 🔥 **စုံထောက်ကြီး** (applause) ရောက်လာပြီ!  '),
    'စုံထောက်ကြီး ရောက်လာပြီ!'
  );
  assert.throws(() => validateEdgeTtsInputText('[Music] 🔥 ...'), /TTS စာသား/);

  const singleSentence = 'မိုးရွာနေတဲ့ညမှာ စုံထောက်ကြီးက လျှို့ဝှက်သဲလွန်စတစ်ခုကို ရှာတွေ့သွားတယ်။ ';
  const longRecap = singleSentence.repeat(32); // > 2000 chars
  assert.ok(longRecap.length > 1800);

  const chunks = splitTextIntoTtsChunks(longRecap, 850);
  assert.ok(chunks.length >= 3);
  for (const chunk of chunks) {
    assert.ok(chunk.length > 0 && chunk.length <= 850, `Chunk length exceeded 850: ${chunk.length}`);
    assert.ok(sanitizeTtsSpeechText(chunk).length > 0);
  }
});

test('parseJsonResponseSafe gracefully handles HTML <!doctype> gateway/404/413 responses instead of throwing SyntaxError', async () => {
  const makeRes = (status: number, body: string) => ({
    status,
    ok: status >= 200 && status < 300,
    text: async () => body,
  });

  const valid = await parseJsonResponseSafe(makeRes(200, '{"ok":true,"count":4}'));
  assert.deepEqual(valid, { ok: true, count: 4 });

  const html200 = await parseJsonResponseSafe(makeRes(200, '<!doctype html><html><body>SPA</body></html>'));
  assert.ok(String(html200.errorMy).includes('HTML'));

  const html504 = await parseJsonResponseSafe(makeRes(504, '<!doctype html><html><title>504 Gateway Timeout</title></html>'));
  assert.ok(String(html504.errorMy).includes('HTTP 504'));

  const html413 = await parseJsonResponseSafe(makeRes(413, '<!doctype html><html>413 Payload Too Large</html>'));
  assert.ok(String(html413.errorMy).includes('ဖိုင်အရွယ်အစား'));

  const html404 = await parseJsonResponseSafe(makeRes(404, '<!doctype html><html>Not Found</html>'));
  assert.ok(String(html404.errorMy).includes('404'));

  const emptyErr = await parseJsonResponseSafe(makeRes(500, ''));
  assert.ok(String(emptyErr.errorMy).includes('500'));
});



